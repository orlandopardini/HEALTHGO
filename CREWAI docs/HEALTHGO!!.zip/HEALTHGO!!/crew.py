import os

from crewai import LLM
from crewai import Agent, Crew, Process, Task
from crewai.project import CrewBase, agent, crew, task
from crewai_tools import (
	SerperDevTool
)





@CrewBase
class IntelligentHealthPlatformMvpBuilderCrew:
    """IntelligentHealthPlatformMvpBuilder crew"""

    
    @agent
    def health_data_interviewer_agent(self) -> Agent:
        
        return Agent(
            config=self.agents_config["health_data_interviewer_agent"],
            
            
            tools=[],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4.1-mini",
                temperature=0.7,
                
            ),
            
        )
    
    @agent
    def health_risk_assessment_agent(self) -> Agent:
        
        return Agent(
            config=self.agents_config["health_risk_assessment_agent"],
            
            
            tools=[				SerperDevTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4.1-mini",
                temperature=0.7,
                
            ),
            
        )
    
    @agent
    def nutrition_planning_agent(self) -> Agent:
        
        return Agent(
            config=self.agents_config["nutrition_planning_agent"],
            
            
            tools=[				SerperDevTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4.1-mini",
                temperature=0.7,
                
            ),
            
        )
    
    @agent
    def personal_training_agent(self) -> Agent:
        
        return Agent(
            config=self.agents_config["personal_training_agent"],
            
            
            tools=[				SerperDevTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4.1-mini",
                temperature=0.7,
                
            ),
            
        )
    
    @agent
    def financial_planning_agent(self) -> Agent:
        
        return Agent(
            config=self.agents_config["financial_planning_agent"],
            
            
            tools=[				SerperDevTool()],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4.1-mini",
                temperature=0.7,
                
            ),
            
        )
    
    @agent
    def progress_tracking_agent(self) -> Agent:
        
        return Agent(
            config=self.agents_config["progress_tracking_agent"],
            
            
            tools=[],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4.1-mini",
                temperature=0.7,
                
            ),
            
        )
    
    @agent
    def mvp_frontend_developer_agent(self) -> Agent:
        
        return Agent(
            config=self.agents_config["mvp_frontend_developer_agent"],
            
            
            tools=[],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4.1-mini",
                temperature=0.7,
                
            ),
            
        )
    
    @agent
    def supabase_database_manager_agent(self) -> Agent:
        
        return Agent(
            config=self.agents_config["supabase_database_manager_agent"],
            
            
            tools=[],
            reasoning=False,
            max_reasoning_attempts=None,
            inject_date=True,
            allow_delegation=False,
            max_iter=25,
            max_rpm=None,
            
            
            max_execution_time=None,
            llm=LLM(
                model="openai/gpt-4.1-mini",
                temperature=0.7,
                
            ),
            
        )
    

    
    @task
    def generate_mock_user_data_and_profiles(self) -> Task:
        return Task(
            config=self.tasks_config["generate_mock_user_data_and_profiles"],
            markdown=False,
            
            
        )
    
    @task
    def health_risk_assessment_and_safety_classification(self) -> Task:
        return Task(
            config=self.tasks_config["health_risk_assessment_and_safety_classification"],
            markdown=False,
            
            
        )
    
    @task
    def create_personalized_nutrition_plans(self) -> Task:
        return Task(
            config=self.tasks_config["create_personalized_nutrition_plans"],
            markdown=False,
            
            
        )
    
    @task
    def design_personalized_training_programs(self) -> Task:
        return Task(
            config=self.tasks_config["design_personalized_training_programs"],
            markdown=False,
            
            
        )
    
    @task
    def financial_planning_and_budget_optimization(self) -> Task:
        return Task(
            config=self.tasks_config["financial_planning_and_budget_optimization"],
            markdown=False,
            
            
        )
    
    @task
    def generate_progress_tracking_system_and_mock_data(self) -> Task:
        return Task(
            config=self.tasks_config["generate_progress_tracking_system_and_mock_data"],
            markdown=False,
            
            
        )
    
    @task
    def build_professional_health_platform_mvp_frontend(self) -> Task:
        return Task(
            config=self.tasks_config["build_professional_health_platform_mvp_frontend"],
            markdown=False,
            
            
        )
    
    @task
    def configure_supabase_database_infrastructure(self) -> Task:
        return Task(
            config=self.tasks_config["configure_supabase_database_infrastructure"],
            markdown=False,
            
            
        )
    

    @crew
    def crew(self) -> Crew:
        """Creates the IntelligentHealthPlatformMvpBuilder crew"""
        return Crew(
            agents=self.agents,  # Automatically created by the @agent decorator
            tasks=self.tasks,  # Automatically created by the @task decorator
            process=Process.sequential,
            verbose=True,
            chat_llm=LLM(model="openai/gpt-4.1-mini"),
        )


