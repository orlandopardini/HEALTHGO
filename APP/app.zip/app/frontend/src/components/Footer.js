import React from 'react';

function Footer() {
  return (
    <footer className="footer">
      <div className="container">
        <p>&copy; 2026 Plataforma Inteligente de Saúde. Desenvolvido com CrewAI.</p>
        <p style={{ marginTop: '10px', fontSize: '14px' }}>
          Sua jornada de saúde personalizada com inteligência artificial
        </p>
      </div>
    </footer>
  );
}

export default Footer;
