import React from 'react';
import { Link } from 'react-router-dom';

function Header() {
  return (
    <header className="header">
      <div className="container">
        <div className="header-content">
          <Link to="/" className="header-logo">
            🏥 Health Platform
          </Link>
          <nav className="header-nav">
            <Link to="/">Home</Link>
            <Link to="/dashboard">Dashboard</Link>
            <Link to="/nutrition">Nutrição</Link>
            <Link to="/training">Treino</Link>
            <Link to="/progress">Progresso</Link>
            <Link to="/financial">Financeiro</Link>
          </nav>
        </div>
      </div>
    </header>
  );
}

export default Header;
