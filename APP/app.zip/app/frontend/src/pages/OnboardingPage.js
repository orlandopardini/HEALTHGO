import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../services/api';

function OnboardingPage() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    age: '',
    gender: 'male',
    height: '',
    weight: '',
    activity_level: 'sedentary',
    goal: 'weight_loss',
    dietary_restrictions: [],
    medical_conditions: [],
    budget: '',
    equipment_available: [],
    time_available: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);

    try {
      // Converte strings para números onde necessário
      const data = {
        ...formData,
        age: parseInt(formData.age),
        height: parseFloat(formData.height),
        weight: parseFloat(formData.weight),
        budget: formData.budget ? parseFloat(formData.budget) : null,
        time_available: formData.time_available ? parseInt(formData.time_available) : null
      };

      // Envia para a API
      const response = await api.post('/api/users/onboard', data);
      
      console.log('Usuário cadastrado:', response.data);
      
      // Redireciona para o dashboard
      navigate('/dashboard');
    } catch (error) {
      console.error('Erro ao cadastrar usuário:', error);
      alert('Erro ao processar cadastro. Tente novamente.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container">
      <div style={{ maxWidth: '700px', margin: '0 auto' }}>
        <h1 style={{ textAlign: 'center', marginBottom: '40px', color: '#111827' }}>
          Vamos Começar sua Jornada de Saúde
        </h1>

        <form onSubmit={handleSubmit} className="onboarding-form">
          {/* Informações Pessoais */}
          <div className="form-section">
            <h3>📋 Informações Pessoais</h3>
            
            <div className="form-group">
              <label className="form-label">Nome Completo</label>
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleChange}
                className="form-input"
                required
              />
            </div>

            <div className="grid grid-2">
              <div className="form-group">
                <label className="form-label">Idade</label>
                <input
                  type="number"
                  name="age"
                  value={formData.age}
                  onChange={handleChange}
                  className="form-input"
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label">Gênero</label>
                <select
                  name="gender"
                  value={formData.gender}
                  onChange={handleChange}
                  className="form-select"
                >
                  <option value="male">Masculino</option>
                  <option value="female">Feminino</option>
                  <option value="other">Outro</option>
                </select>
              </div>
            </div>

            <div className="grid grid-2">
              <div className="form-group">
                <label className="form-label">Altura (cm)</label>
                <input
                  type="number"
                  name="height"
                  value={formData.height}
                  onChange={handleChange}
                  className="form-input"
                  step="0.1"
                  required
                />
              </div>

              <div className="form-group">
                <label className="form-label">Peso (kg)</label>
                <input
                  type="number"
                  name="weight"
                  value={formData.weight}
                  onChange={handleChange}
                  className="form-input"
                  step="0.1"
                  required
                />
              </div>
            </div>
          </div>

          {/* Objetivos e Estilo de Vida */}
          <div className="form-section">
            <h3>🎯 Objetivos e Estilo de Vida</h3>

            <div className="form-group">
              <label className="form-label">Nível de Atividade</label>
              <select
                name="activity_level"
                value={formData.activity_level}
                onChange={handleChange}
                className="form-select"
              >
                <option value="sedentary">Sedentário (pouco ou nenhum exercício)</option>
                <option value="lightly_active">Levemente Ativo (1-3 dias/semana)</option>
                <option value="moderately_active">Moderadamente Ativo (3-5 dias/semana)</option>
                <option value="very_active">Muito Ativo (6-7 dias/semana)</option>
                <option value="extremely_active">Extremamente Ativo (atleta)</option>
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Objetivo Principal</label>
              <select
                name="goal"
                value={formData.goal}
                onChange={handleChange}
                className="form-select"
              >
                <option value="weight_loss">Perda de Peso</option>
                <option value="muscle_gain">Ganho de Massa Muscular</option>
                <option value="maintenance">Manutenção de Saúde</option>
                <option value="athletic_performance">Performance Atlética</option>
                <option value="general_fitness">Condicionamento Geral</option>
              </select>
            </div>

            <div className="form-group">
              <label className="form-label">Tempo Disponível para Exercícios (min/dia)</label>
              <input
                type="number"
                name="time_available"
                value={formData.time_available}
                onChange={handleChange}
                className="form-input"
                placeholder="Ex: 60"
              />
            </div>
          </div>

          {/* Informações Financeiras */}
          <div className="form-section">
            <h3>💰 Orçamento</h3>

            <div className="form-group">
              <label className="form-label">Orçamento Mensal (R$)</label>
              <input
                type="number"
                name="budget"
                value={formData.budget}
                onChange={handleChange}
                className="form-input"
                step="0.01"
                placeholder="Ex: 500.00"
              />
              <small style={{ color: '#6b7280', marginTop: '8px', display: 'block' }}>
                Inclui alimentação, academia, suplementos, etc.
              </small>
            </div>
          </div>

          {/* Botão de Envio */}
          <div style={{ textAlign: 'center', marginTop: '30px' }}>
            <button 
              type="submit" 
              className="btn btn-primary"
              disabled={loading}
              style={{ minWidth: '200px' }}
            >
              {loading ? 'Processando...' : 'Criar Meu Plano'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default OnboardingPage;
