import React, { useState, useEffect } from 'react';

function FinancialPage() {
  const [financialData, setFinancialData] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadFinancialData();
  }, []);

  const loadFinancialData = async () => {
    setLoading(true);
    try {
      // Mock data
      setTimeout(() => {
        setFinancialData({
          monthly_costs: {
            nutrition: 380.00,
            gym_membership: 89.00,
            supplements: 120.00,
            equipment: 50.00,
            personal_trainer: 0.00,
            other: 30.00
          },
          total_monthly: 669.00,
          budget: 800.00,
          budget_status: 'within_budget',
          cost_breakdown: [
            { category: 'Nutrição', amount: 380.00, percentage: 56.8 },
            { category: 'Academia', amount: 89.00, percentage: 13.3 },
            { category: 'Suplementos', amount: 120.00, percentage: 17.9 },
            { category: 'Equipamentos', amount: 50.00, percentage: 7.5 },
            { category: 'Outros', amount: 30.00, percentage: 4.5 }
          ],
          savings_opportunities: [
            { suggestion: 'Comprar alimentos a granel', potential_saving: 50.00 },
            { suggestion: 'Treinar em casa 2x por semana', potential_saving: 30.00 },
            { suggestion: 'Substituir whey por ovos em 1 refeição', potential_saving: 25.00 }
          ],
          alternatives: {
            'Academia Premium': {
              current: 89.00,
              alternative: 'Academia Básica',
              new_cost: 49.00,
              savings: 40.00
            },
            'Suplementos Premium': {
              current: 120.00,
              alternative: 'Suplementos Nacionais',
              new_cost: 80.00,
              savings: 40.00
            }
          }
        });
        setLoading(false);
      }, 500);
    } catch (error) {
      console.error('Erro ao carregar dados financeiros:', error);
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="container">
        <div className="spinner"></div>
      </div>
    );
  }

  if (!financialData) {
    return (
      <div className="container">
        <div className="card">
          <h2>Nenhum dado financeiro disponível</h2>
          <p>Complete o onboarding para ver sua análise financeira.</p>
        </div>
      </div>
    );
  }

  const remainingBudget = financialData.budget - financialData.total_monthly;
  const budgetUsagePercentage = (financialData.total_monthly / financialData.budget * 100).toFixed(1);

  return (
    <div className="container">
      <h1 style={{ marginBottom: '30px' }}>💰 Planejamento Financeiro</h1>

      {/* Resumo Financeiro */}
      <div className="card">
        <h2 className="card-title">Resumo Mensal</h2>
        <div className="grid grid-3">
          <div className="stat-card">
            <div className="stat-label">Gasto Mensal</div>
            <div className="stat-value">R$ {financialData.total_monthly.toFixed(2)}</div>
            <small style={{ color: '#6b7280' }}>Total investido em saúde</small>
          </div>
          <div className="stat-card">
            <div className="stat-label">Orçamento</div>
            <div className="stat-value">R$ {financialData.budget.toFixed(2)}</div>
            <small style={{ color: '#6b7280' }}>Limite mensal</small>
          </div>
          <div className="stat-card">
            <div className="stat-label">Saldo</div>
            <div className="stat-value" style={{ color: remainingBudget >= 0 ? '#10b981' : '#ef4444' }}>
              R$ {remainingBudget.toFixed(2)}
            </div>
            <span className={`badge ${remainingBudget >= 0 ? 'badge-success' : 'badge-danger'}`}>
              {budgetUsagePercentage}% do orçamento
            </span>
          </div>
        </div>

        {/* Barra de progresso do orçamento */}
        <div style={{ marginTop: '30px' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8px' }}>
            <span style={{ fontWeight: 600 }}>Uso do Orçamento</span>
            <span style={{ color: '#6b7280' }}>{budgetUsagePercentage}%</span>
          </div>
          <div style={{
            width: '100%',
            height: '12px',
            backgroundColor: '#e5e7eb',
            borderRadius: '6px',
            overflow: 'hidden'
          }}>
            <div style={{
              width: `${Math.min(budgetUsagePercentage, 100)}%`,
              height: '100%',
              backgroundColor: budgetUsagePercentage < 80 ? '#10b981' : budgetUsagePercentage < 95 ? '#f59e0b' : '#ef4444',
              borderRadius: '6px',
              transition: 'width 0.3s ease'
            }} />
          </div>
        </div>
      </div>

      {/* Distribuição de Custos */}
      <div className="card">
        <h2 className="card-title">Distribuição de Custos</h2>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse' }}>
            <thead>
              <tr style={{ backgroundColor: '#f9fafb', borderBottom: '2px solid #e5e7eb' }}>
                <th style={{ padding: '12px', textAlign: 'left' }}>Categoria</th>
                <th style={{ padding: '12px', textAlign: 'right' }}>Valor</th>
                <th style={{ padding: '12px', textAlign: 'center' }}>Percentual</th>
                <th style={{ padding: '12px', textAlign: 'center' }}>Visualização</th>
              </tr>
            </thead>
            <tbody>
              {financialData.cost_breakdown.map((item, index) => (
                <tr key={index} style={{ borderBottom: '1px solid #e5e7eb' }}>
                  <td style={{ padding: '12px' }}><strong>{item.category}</strong></td>
                  <td style={{ padding: '12px', textAlign: 'right' }}>
                    R$ {item.amount.toFixed(2)}
                  </td>
                  <td style={{ padding: '12px', textAlign: 'center' }}>
                    {item.percentage.toFixed(1)}%
                  </td>
                  <td style={{ padding: '12px' }}>
                    <div style={{
                      width: '100%',
                      maxWidth: '200px',
                      height: '8px',
                      backgroundColor: '#e5e7eb',
                      borderRadius: '4px',
                      overflow: 'hidden',
                      margin: '0 auto'
                    }}>
                      <div style={{
                        width: `${item.percentage}%`,
                        height: '100%',
                        backgroundColor: '#4f46e5',
                        borderRadius: '4px'
                      }} />
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Oportunidades de Economia */}
      <div className="card">
        <h2 className="card-title">💡 Oportunidades de Economia</h2>
        <p style={{ marginBottom: '20px', color: '#6b7280' }}>
          Identifique maneiras de reduzir custos sem comprometer resultados:
        </p>
        <div className="grid grid-2">
          {financialData.savings_opportunities.map((opportunity, index) => (
            <div key={index} style={{
              padding: '20px',
              backgroundColor: '#f0fdf4',
              borderRadius: '12px',
              borderLeft: '4px solid #22c55e'
            }}>
              <h3 style={{ fontSize: '16px', marginBottom: '10px', color: '#065f46' }}>
                {opportunity.suggestion}
              </h3>
              <p style={{ margin: 0, color: '#047857', fontWeight: 600, fontSize: '20px' }}>
                Economia: R$ {opportunity.potential_saving.toFixed(2)}/mês
              </p>
            </div>
          ))}
        </div>
        <div style={{ marginTop: '20px', padding: '15px', backgroundColor: '#fef3c7', borderRadius: '8px', textAlign: 'center' }}>
          <strong style={{ color: '#92400e' }}>
            Economia Total Potencial: R$ {financialData.savings_opportunities.reduce((sum, opp) => sum + opp.potential_saving, 0).toFixed(2)}/mês
          </strong>
        </div>
      </div>

      {/* Alternativas Econômicas */}
      <div className="card">
        <h2 className="card-title">🔄 Alternativas Econômicas</h2>
        <p style={{ marginBottom: '20px', color: '#6b7280' }}>
          Compare opções mais econômicas para seus principais gastos:
        </p>
        {Object.entries(financialData.alternatives).map(([key, alt], index) => (
          <div key={index} style={{
            padding: '20px',
            backgroundColor: '#fff',
            borderRadius: '12px',
            border: '2px solid #e5e7eb',
            marginBottom: '15px'
          }}>
            <h3 style={{ fontSize: '18px', marginBottom: '15px' }}>{key}</h3>
            <div className="grid grid-2" style={{ gap: '20px' }}>
              <div style={{ padding: '15px', backgroundColor: '#fee2e2', borderRadius: '8px' }}>
                <div style={{ color: '#991b1b', marginBottom: '8px' }}>Atual</div>
                <div style={{ fontSize: '24px', fontWeight: 700, color: '#7f1d1d' }}>
                  R$ {alt.current.toFixed(2)}
                </div>
              </div>
              <div style={{ padding: '15px', backgroundColor: '#d1fae5', borderRadius: '8px' }}>
                <div style={{ color: '#065f46', marginBottom: '8px' }}>{alt.alternative}</div>
                <div style={{ fontSize: '24px', fontWeight: 700, color: '#047857' }}>
                  R$ {alt.new_cost.toFixed(2)}
                </div>
              </div>
            </div>
            <div style={{ marginTop: '15px', textAlign: 'center', padding: '10px', backgroundColor: '#f0fdf4', borderRadius: '8px' }}>
              <strong style={{ color: '#047857' }}>
                💰 Economia de R$ {alt.savings.toFixed(2)}/mês
              </strong>
            </div>
          </div>
        ))}
      </div>

      {/* Dicas Financeiras */}
      <div className="card">
        <h2 className="card-title">📌 Dicas para Otimizar seu Orçamento</h2>
        <ul style={{ marginLeft: '20px', lineHeight: '2' }}>
          <li>Compare preços em diferentes supermercados e compre em atacado</li>
          <li>Cozinhe suas refeições em batch (prepare várias de uma vez)</li>
          <li>Aproveite promoções de alimentos saudáveis</li>
          <li>Considere treinar em casa alguns dias para economizar com academia</li>
          <li>Pesquise marcas genéricas de suplementos com boa qualidade</li>
          <li>Use apps de cashback e programas de fidelidade</li>
          <li>Priorize alimentos da estação - são mais baratos e frescos</li>
        </ul>
      </div>
    </div>
  );
}

export default FinancialPage;
