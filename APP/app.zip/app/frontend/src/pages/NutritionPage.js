import React, { useState, useEffect } from 'react';
import api from '../services/api';

function NutritionPage() {
  const [nutritionPlan, setNutritionPlan] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadNutritionPlan();
  }, []);

  const loadNutritionPlan = async () => {
    setLoading(true);
    try {
      // Mock data - substituir com chamada real à API
      setTimeout(() => {
        setNutritionPlan({
          daily_calories: 2000,
          macros: {
            protein: 150,
            carbs: 200,
            fats: 65
          },
          meal_plan: [
            {
              meal: 'Café da Manhã',
              time: '08:00',
              foods: ['Aveia (60g)', 'Banana (1 unid)', 'Whey Protein (30g)', 'Amendoim (20g)'],
              calories: 480,
              macros: { protein: 35, carbs: 55, fats: 15 }
            },
            {
              meal: 'Almoço',
              time: '13:00',
              foods: ['Frango grelhado (150g)', 'Arroz integral (100g)', 'Feijão (80g)', 'Brócolis (150g)', 'Salada verde'],
              calories: 620,
              macros: { protein: 50, carbs: 70, fats: 12 }
            },
            {
              meal: 'Lanche da Tarde',
              time: '16:00',
              foods: ['Iogurte grego (200g)', 'Granola (30g)', 'Morango (100g)'],
              calories: 320,
              macros: { protein: 25, carbs: 35, fats: 10 }
            },
            {
              meal: 'Jantar',
              time: '19:30',
              foods: ['Salmão grelhado (150g)', 'Batata doce (150g)', 'Aspargos (100g)', 'Azeite (1 colher)'],
              calories: 580,
              macros: { protein: 40, carbs: 40, fats: 28 }
            }
          ],
          estimated_cost: 380.00,
          substitutions: {
            'Frango grelhado': ['Peixe branco', 'Carne moída magra', 'Ovo mexido'],
            'Arroz integral': ['Quinoa', 'Macarrão integral', 'Batata doce'],
            'Salmão': ['Sardinha', 'Atum', 'Tilápia']
          }
        });
        setLoading(false);
      }, 500);
    } catch (error) {
      console.error('Erro ao carregar plano nutricional:', error);
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="container">
        <div className="spinner"></div>
      </div>
    );
  }

  if (!nutritionPlan) {
    return (
      <div className="container">
        <div className="card">
          <h2>Nenhum plano nutricional disponível</h2>
          <p>Complete o onboarding para gerar seu plano personalizado.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container">
      <h1 style={{ marginBottom: '30px' }}>🍎 Plano Nutricional</h1>

      {/* Resumo do Plano */}
      <div className="card">
        <h2 className="card-title">Resumo Diário</h2>
        <div className="grid grid-3">
          <div className="stat-card">
            <div className="stat-label">Calorias</div>
            <div className="stat-value">{nutritionPlan.daily_calories}</div>
            <small style={{ color: '#6b7280' }}>kcal/dia</small>
          </div>
          <div className="stat-card">
            <div className="stat-label">Proteína</div>
            <div className="stat-value">{nutritionPlan.macros.protein}g</div>
            <small style={{ color: '#6b7280' }}>{Math.round(nutritionPlan.macros.protein * 4 / nutritionPlan.daily_calories * 100)}% das calorias</small>
          </div>
          <div className="stat-card">
            <div className="stat-label">Carboidratos</div>
            <div className="stat-value">{nutritionPlan.macros.carbs}g</div>
            <small style={{ color: '#6b7280' }}>{Math.round(nutritionPlan.macros.carbs * 4 / nutritionPlan.daily_calories * 100)}% das calorias</small>
          </div>
        </div>
        <div style={{ marginTop: '20px', textAlign: 'center' }}>
          <p style={{ fontSize: '18px', color: '#4f46e5' }}>
            💰 Custo Estimado: <strong>R$ {nutritionPlan.estimated_cost.toFixed(2)}/mês</strong>
          </p>
        </div>
      </div>

      {/* Plano de Refeições */}
      <h2 style={{ marginTop: '40px', marginBottom: '20px' }}>Plano de Refeições</h2>
      {nutritionPlan.meal_plan.map((meal, index) => (
        <div key={index} className="plan-card">
          <div className="plan-header">
            <h3 style={{ marginBottom: '5px' }}>{meal.meal}</h3>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ color: '#6b7280' }}>⏰ {meal.time}</span>
              <span className="badge badge-info">{meal.calories} kcal</span>
            </div>
          </div>
          <div>
            <strong>Alimentos:</strong>
            <ul style={{ marginTop: '10px', marginLeft: '20px' }}>
              {meal.foods.map((food, i) => (
                <li key={i} style={{ marginBottom: '5px' }}>{food}</li>
              ))}
            </ul>
            <div style={{ marginTop: '15px', padding: '10px', backgroundColor: '#f9fafb', borderRadius: '6px' }}>
              <small style={{ color: '#4b5563' }}>
                <strong>Macros:</strong> Proteína: {meal.macros.protein}g | Carbos: {meal.macros.carbs}g | Gorduras: {meal.macros.fats}g
              </small>
            </div>
          </div>
        </div>
      ))}

      {/* Substituições */}
      <div className="card" style={{ marginTop: '40px' }}>
        <h2 className="card-title">🔄 Substituições Permitidas</h2>
        <p style={{ marginBottom: '20px', color: '#6b7280' }}>
          Você pode substituir os alimentos abaixo mantendo valores nutricionais similares:
        </p>
        <div className="grid grid-2">
          {Object.entries(nutritionPlan.substitutions).map(([food, alternatives], index) => (
            <div key={index} style={{ padding: '15px', backgroundColor: '#f9fafb', borderRadius: '8px', marginBottom: '10px' }}>
              <strong style={{ color: '#4f46e5' }}>{food}</strong>
              <ul style={{ marginTop: '8px', marginLeft: '20px' }}>
                {alternatives.map((alt, i) => (
                  <li key={i} style={{ color: '#6b7280' }}>{alt}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* Dicas */}
      <div className="card">
        <h2 className="card-title">💡 Dicas Nutricionais</h2>
        <ul style={{ marginLeft: '20px', lineHeight: '2' }}>
          <li>Beba pelo menos 2-3 litros de água por dia</li>
          <li>Prepare as refeições com antecedência nos fins de semana</li>
          <li>Use temperos naturais para variar o sabor sem adicionar calorias</li>
          <li>Inclua vegetais em pelo menos 2 refeições por dia</li>
          <li>Não pule refeições - mantenha o metabolismo ativo</li>
        </ul>
      </div>
    </div>
  );
}

export default NutritionPage;
