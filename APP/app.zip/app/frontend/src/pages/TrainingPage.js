import React, { useState, useEffect } from 'react';
import api from '../services/api';

function TrainingPage() {
  const [trainingProgram, setTrainingProgram] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadTrainingProgram();
  }, []);

  const loadTrainingProgram = async () => {
    setLoading(true);
    try {
      // Mock data
      setTimeout(() => {
        setTrainingProgram({
          program_type: 'Força & Condicionamento',
          duration_weeks: 12,
          weekly_schedule: [
            {
              day: 'Segunda-feira',
              focus: 'Peito & Tríceps',
              duration: 60,
              exercises: [
                { name: 'Supino reto', sets: 4, reps: '8-12', rest: '90s', notes: 'Aumente peso progressivamente' },
                { name: 'Supino inclinado com halteres', sets: 3, reps: '10-12', rest: '60s' },
                { name: 'Crucifixo', sets: 3, reps: '12-15', rest: '60s' },
                { name: 'Tríceps pulley', sets: 3, reps: '12-15', rest: '45s' },
                { name: 'Tríceps testa', sets: 3, reps: '10-12', rest: '60s' }
              ]
            },
            {
              day: 'Quarta-feira',
              focus: 'Costas & Bíceps',
              duration: 60,
              exercises: [
                { name: 'Barra fixa', sets: 4, reps: '6-10', rest: '90s', notes: 'Use auxiliador se necessário' },
                { name: 'Remada curvada', sets: 4, reps: '8-12', rest: '90s' },
                { name: 'Pulldown', sets: 3, reps: '10-12', rest: '60s' },
                { name: 'Rosca direta', sets: 3, reps: '10-12', rest: '60s' },
                { name: 'Rosca martelo', sets: 3, reps: '12-15', rest: '45s' }
              ]
            },
            {
              day: 'Sexta-feira',
              focus: 'Pernas & Ombros',
              duration: 70,
              exercises: [
                { name: 'Agachamento', sets: 4, reps: '8-12', rest: '120s', notes: 'Exercício principal' },
                { name: 'Leg press', sets: 3, reps: '10-15', rest: '90s' },
                { name: 'Stiff', sets: 3, reps: '10-12', rest: '90s' },
                { name: 'Desenvolvimento militar', sets: 4, reps: '8-12', rest: '90s' },
                { name: 'Elevação lateral', sets: 3, reps: '12-15', rest: '60s' },
                { name: 'Panturrilha em pé', sets: 4, reps: '15-20', rest: '45s' }
              ]
            }
          ],
          progression_notes: 'Aumente a carga em 2.5-5kg quando conseguir completar todas as séries com boa forma.',
          equipment_needed: ['Barra', 'Halteres', 'Banco ajustável', 'Máquinas básicas de academia']
        });
        setLoading(false);
      }, 500);
    } catch (error) {
      console.error('Erro ao carregar programa de treino:', error);
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="container">
        <div className="spinner"></div>
      </div>
    );
  }

  if (!trainingProgram) {
    return (
      <div className="container">
        <div className="card">
          <h2>Nenhum programa de treino disponível</h2>
          <p>Complete o onboarding para gerar seu programa personalizado.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="container">
      <h1 style={{ marginBottom: '30px' }}>💪 Programa de Treinamento</h1>

      {/* Informações do Programa */}
      <div className="card">
        <h2 className="card-title">Informações do Programa</h2>
        <div className="grid grid-2">
          <div>
            <p><strong>Tipo:</strong> {trainingProgram.program_type}</p>
            <p><strong>Duração:</strong> {trainingProgram.duration_weeks} semanas</p>
            <p><strong>Frequência:</strong> {trainingProgram.weekly_schedule.length}x por semana</p>
          </div>
          <div>
            <p><strong>Equipamentos Necessários:</strong></p>
            <ul style={{ marginLeft: '20px', marginTop: '8px' }}>
              {trainingProgram.equipment_needed.map((equip, i) => (
                <li key={i} style={{ color: '#6b7280' }}>{equip}</li>
              ))}
            </ul>
          </div>
        </div>
        <div style={{ marginTop: '20px', padding: '15px', backgroundColor: '#fef3c7', borderRadius: '8px', borderLeft: '4px solid #f59e0b' }}>
          <strong>⚡ Progressão:</strong> {trainingProgram.progression_notes}
        </div>
      </div>

      {/* Cronograma Semanal */}
      <h2 style={{ marginTop: '40px', marginBottom: '20px' }}>Cronograma Semanal</h2>
      {trainingProgram.weekly_schedule.map((workout, index) => (
        <div key={index} className="plan-card">
          <div className="plan-header">
            <h3 style={{ marginBottom: '5px' }}>{workout.day}</h3>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ color: '#6b7280' }}>{workout.focus}</span>
              <span className="badge badge-info">⏱️ {workout.duration} min</span>
            </div>
          </div>
          
          <div style={{ marginTop: '20px' }}>
            <table style={{ width: '100%', borderCollapse: 'collapse' }}>
              <thead>
                <tr style={{ backgroundColor: '#f9fafb', borderBottom: '2px solid #e5e7eb' }}>
                  <th style={{ padding: '12px', textAlign: 'left' }}>Exercício</th>
                  <th style={{ padding: '12px', textAlign: 'center' }}>Séries</th>
                  <th style={{ padding: '12px', textAlign: 'center' }}>Reps</th>
                  <th style={{ padding: '12px', textAlign: 'center' }}>Descanso</th>
                </tr>
              </thead>
              <tbody>
                {workout.exercises.map((exercise, i) => (
                  <tr key={i} style={{ borderBottom: '1px solid #e5e7eb' }}>
                    <td style={{ padding: '12px' }}>
                      <strong>{exercise.name}</strong>
                      {exercise.notes && (
                        <div style={{ fontSize: '12px', color: '#6b7280', marginTop: '4px' }}>
                          💡 {exercise.notes}
                        </div>
                      )}
                    </td>
                    <td style={{ padding: '12px', textAlign: 'center' }}>{exercise.sets}</td>
                    <td style={{ padding: '12px', textAlign: 'center' }}>{exercise.reps}</td>
                    <td style={{ padding: '12px', textAlign: 'center' }}>{exercise.rest}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ))}

      {/* Dicas de Treino */}
      <div className="card">
        <h2 className="card-title">💡 Dicas de Treino</h2>
        <ul style={{ marginLeft: '20px', lineHeight: '2' }}>
          <li><strong>Aquecimento:</strong> Sempre faça 5-10 minutos de cardio leve antes de treinar</li>
          <li><strong>Forma correta:</strong> Priorize a execução perfeita sobre pesos pesados</li>
          <li><strong>Descanso:</strong> Durma 7-9 horas por noite para recuperação adequada</li>
          <li><strong>Hidratação:</strong> Beba água antes, durante e após o treino</li>
          <li><strong>Progressão:</strong> Aumente carga apenas quando conseguir completar todas as séries</li>
          <li><strong>Alongamento:</strong> Faça alongamento estático após o treino</li>
        </ul>
      </div>

      {/* Avisos de Segurança */}
      <div className="card" style={{ backgroundColor: '#fee2e2', border: '2px solid #fca5a5' }}>
        <h2 className="card-title" style={{ color: '#991b1b' }}>⚠️ Avisos de Segurança</h2>
        <ul style={{ marginLeft: '20px', lineHeight: '2', color: '#7f1d1d' }}>
          <li>Consulte um médico antes de iniciar qualquer programa de exercícios</li>
          <li>Pare imediatamente se sentir dor aguda ou desconforto incomum</li>
          <li>Use um parceiro de treino para exercícios pesados como supino</li>
          <li>Mantenha boa hidratação durante todo o treino</li>
          <li>Respeite os dias de descanso para evitar overtraining</li>
        </ul>
      </div>
    </div>
  );
}

export default TrainingPage;
