import React, { useState, useEffect } from 'react';
import api from '../services/api';

function DashboardPage() {
  const [stats, setStats] = useState({
    weight: 75.5,
    bmi: 23.2,
    workouts_week: 3,
    adherence: 85
  });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    setLoading(true);
    try {
      // TODO: Carregar dados reais da API
      // const response = await api.get('/api/progress/user_123');
      // setStats(response.data.metrics);
      
      // Dados mockados por enquanto
      setTimeout(() => {
        setLoading(false);
      }, 500);
    } catch (error) {
      console.error('Erro ao carregar dados:', error);
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="container">
        <div className="spinner"></div>
      </div>
    );
  }

  return (
    <div className="container">
      <h1 style={{ marginBottom: '30px' }}>Dashboard de Saúde</h1>

      {/* Cards de Estatísticas */}
      <div className="dashboard-grid">
        <div className="stat-card">
          <div className="stat-label">Peso Atual</div>
          <div className="stat-value">{stats.weight} kg</div>
          <span className="badge badge-success">↓ 2.5 kg este mês</span>
        </div>

        <div className="stat-card">
          <div className="stat-label">IMC</div>
          <div className="stat-value">{stats.bmi}</div>
          <span className="badge badge-success">Normal</span>
        </div>

        <div className="stat-card">
          <div className="stat-label">Treinos/Semana</div>
          <div className="stat-value">{stats.workouts_week}</div>
          <span className="badge badge-info">Meta: 4x</span>
        </div>

        <div className="stat-card">
          <div className="stat-label">Aderência</div>
          <div className="stat-value">{stats.adherence}%</div>
          <span className="badge badge-success">Excelente!</span>
        </div>
      </div>

      {/* Resumo Semanal */}
      <div className="card">
        <h2 className="card-title">📊 Resumo da Semana</h2>
        <div className="grid grid-2">
          <div>
            <h3 style={{ fontSize: '16px', marginBottom: '15px', color: '#4f46e5' }}>
              Nutrição
            </h3>
            <ul style={{ listStyle: 'none', padding: 0 }}>
              <li style={{ marginBottom: '10px' }}>
                ✅ Meta calórica atingida: 5/7 dias
              </li>
              <li style={{ marginBottom: '10px' }}>
                ✅ Proteína média: 145g/dia
              </li>
              <li style={{ marginBottom: '10px' }}>
                ⚠️ Hidratação: melhorar
              </li>
            </ul>
          </div>
          <div>
            <h3 style={{ fontSize: '16px', marginBottom: '15px', color: '#4f46e5' }}>
              Treino
            </h3>
            <ul style={{ listStyle: 'none', padding: 0 }}>
              <li style={{ marginBottom: '10px' }}>
                ✅ 3 treinos completados
              </li>
              <li style={{ marginBottom: '10px' }}>
                ✅ 180 minutos de exercício
              </li>
              <li style={{ marginBottom: '10px' }}>
                💪 Força aumentada em 5%
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Próximas Ações */}
      <div className="card">
        <h2 className="card-title">🎯 Próximas Ações</h2>
        <div className="plan-item">
          <strong>Treino de Hoje:</strong> Upper Body - Força
          <br />
          <small style={{ color: '#6b7280' }}>60 minutos • 6 exercícios</small>
        </div>
        <div className="plan-item">
          <strong>Refeição Planejada:</strong> Frango grelhado com batata doce
          <br />
          <small style={{ color: '#6b7280' }}>550 calorias • 45g proteína</small>
        </div>
        <div className="plan-item">
          <strong>Lembrete:</strong> Check-in semanal de progresso
          <br />
          <small style={{ color: '#6b7280' }}>Agende para amanhã</small>
        </div>
      </div>

      {/* Insights de IA */}
      <div className="card">
        <h2 className="card-title">🤖 Insights de IA</h2>
        <div style={{ padding: '20px', backgroundColor: '#f0f9ff', borderRadius: '8px', borderLeft: '4px solid #3b82f6' }}>
          <p style={{ margin: 0, lineHeight: '1.6' }}>
            <strong>Parabéns!</strong> Você está 15% acima da média de aderência.
            Seu progresso constante está gerando resultados excelentes. Continue
            priorizando o sono e recuperação para maximizar seus ganhos.
          </p>
        </div>
      </div>
    </div>
  );
}

export default DashboardPage;
