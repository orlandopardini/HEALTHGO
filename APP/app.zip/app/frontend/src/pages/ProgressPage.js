import React, { useState, useEffect } from 'react';

function ProgressPage() {
  const [progressData, setProgressData] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadProgressData();
  }, []);

  const loadProgressData = async () => {
    setLoading(true);
    try {
      // Mock data
      setTimeout(() => {
        setProgressData({
          current_stats: {
            weight: 75.5,
            body_fat: 18.2,
            muscle_mass: 61.8
          },
          start_stats: {
            weight: 78.0,
            body_fat: 21.5,
            muscle_mass: 61.2
          },
          weekly_progress: [
            { week: 1, weight: 78.0, workouts: 3, adherence: 75 },
            { week: 2, weight: 77.8, workouts: 4, adherence: 85 },
            { week: 3, weight: 77.2, workouts: 4, adherence: 90 },
            { week: 4, weight: 76.5, workouts: 3, adherence: 80 },
            { week: 5, weight: 76.0, workouts: 4, adherence: 95 },
            { week: 6, weight: 75.5, workouts: 3, adherence: 85 }
          ],
          achievements: [
            { title: 'Primeira Semana Completa', date: '2026-02-15', icon: '🎯' },
            { title: 'Perdeu 2kg', date: '2026-03-01', icon: '🎉' },
            { title: '90% de Aderência', date: '2026-03-08', icon: '⭐' }
          ],
          insights: [
            'Você está perdendo peso de forma saudável (média de 0.4kg/semana)',
            'Sua consistência melhorou 20% nas últimas 4 semanas',
            'A massa muscular está sendo preservada - excelente!'
          ]
        });
        setLoading(false);
      }, 500);
    } catch (error) {
      console.error('Erro ao carregar progresso:', error);
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="container">
        <div className="spinner"></div>
      </div>
    );
  }

  if (!progressData) {
    return (
      <div className="container">
        <div className="card">
          <h2>Nenhum dado de progresso disponível</h2>
          <p>Comece seu treino para começar a rastrear seu progresso.</p>
        </div>
      </div>
    );
  }

  const calculateChange = (current, start) => {
    const change = current - start;
    const percentage = ((change / start) * 100).toFixed(1);
    return { value: change.toFixed(1), percentage };
  };

  const weightChange = calculateChange(progressData.current_stats.weight, progressData.start_stats.weight);
  const fatChange = calculateChange(progressData.current_stats.body_fat, progressData.start_stats.body_fat);
  const muscleChange = calculateChange(progressData.current_stats.muscle_mass, progressData.start_stats.muscle_mass);

  return (
    <div className="container">
      <h1 style={{ marginBottom: '30px' }}>📊 Rastreamento de Progresso</h1>

      {/* Estatísticas Atuais */}
      <div className="card">
        <h2 className="card-title">Estatísticas Atuais</h2>
        <div className="grid grid-3">
          <div className="stat-card">
            <div className="stat-label">Peso</div>
            <div className="stat-value">{progressData.current_stats.weight} kg</div>
            <span className={`badge ${weightChange.value < 0 ? 'badge-success' : 'badge-warning'}`}>
              {weightChange.value > 0 ? '+' : ''}{weightChange.value} kg ({weightChange.percentage}%)
            </span>
          </div>
          <div className="stat-card">
            <div className="stat-label">Gordura Corporal</div>
            <div className="stat-value">{progressData.current_stats.body_fat}%</div>
            <span className={`badge ${fatChange.value < 0 ? 'badge-success' : 'badge-warning'}`}>
              {fatChange.value > 0 ? '+' : ''}{fatChange.value}% ({fatChange.percentage}%)
            </span>
          </div>
          <div className="stat-card">
            <div className="stat-label">Massa Muscular</div>
            <div className="stat-value">{progressData.current_stats.muscle_mass} kg</div>
            <span className={`badge ${muscleChange.value > 0 ? 'badge-success' : 'badge-warning'}`}>
              {muscleChange.value > 0 ? '+' : ''}{muscleChange.value} kg ({muscleChange.percentage}%)
            </span>
          </div>
        </div>
      </div>

      {/* Progresso Semanal */}
      <div className="card">
        <h2 className="card-title">Progresso Semanal</h2>
        <div style={{ overflowX: 'auto' }}>
          <table style={{ width: '100%', borderCollapse: 'collapse', minWidth: '600px' }}>
            <thead>
              <tr style={{ backgroundColor: '#f9fafb', borderBottom: '2px solid #e5e7eb' }}>
                <th style={{ padding: '12px', textAlign: 'left' }}>Semana</th>
                <th style={{ padding: '12px', textAlign: 'center' }}>Peso (kg)</th>
                <th style={{ padding: '12px', textAlign: 'center' }}>Treinos</th>
                <th style={{ padding: '12px', textAlign: 'center' }}>Aderência</th>
                <th style={{ padding: '12px', textAlign: 'center' }}>Status</th>
              </tr>
            </thead>
            <tbody>
              {progressData.weekly_progress.map((week, index) => (
                <tr key={index} style={{ borderBottom: '1px solid #e5e7eb' }}>
                  <td style={{ padding: '12px' }}>Semana {week.week}</td>
                  <td style={{ padding: '12px', textAlign: 'center' }}>
                    {week.weight}
                    {index > 0 && (
                      <span style={{ fontSize: '12px', color: '#6b7280', marginLeft: '8px' }}>
                        ({(week.weight - progressData.weekly_progress[index - 1].weight).toFixed(1)})
                      </span>
                    )}
                  </td>
                  <td style={{ padding: '12px', textAlign: 'center' }}>{week.workouts}</td>
                  <td style={{ padding: '12px', textAlign: 'center' }}>
                    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: '8px' }}>
                      <div style={{
                        width: '100px',
                        height: '8px',
                        backgroundColor: '#e5e7eb',
                        borderRadius: '4px',
                        overflow: 'hidden'
                      }}>
                        <div style={{
                          width: `${week.adherence}%`,
                          height: '100%',
                          backgroundColor: week.adherence >= 80 ? '#10b981' : '#f59e0b',
                          borderRadius: '4px'
                        }} />
                      </div>
                      <span>{week.adherence}%</span>
                    </div>
                  </td>
                  <td style={{ padding: '12px', textAlign: 'center' }}>
                    {week.adherence >= 85 ? '🔥' : week.adherence >= 70 ? '👍' : '⚠️'}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Conquistas */}
      <div className="card">
        <h2 className="card-title">🏆 Conquistas</h2>
        <div className="grid grid-3">
          {progressData.achievements.map((achievement, index) => (
            <div key={index} style={{
              padding: '20px',
              backgroundColor: '#f0f9ff',
              borderRadius: '12px',
              textAlign: 'center',
              border: '2px solid #3b82f6'
            }}>
              <div style={{ fontSize: '48px', marginBottom: '10px' }}>{achievement.icon}</div>
              <h3 style={{ fontSize: '16px', marginBottom: '8px' }}>{achievement.title}</h3>
              <small style={{ color: '#6b7280' }}>{achievement.date}</small>
            </div>
          ))}
        </div>
      </div>

      {/* Insights de IA */}
      <div className="card">
        <h2 className="card-title">🤖 Insights de IA</h2>
        {progressData.insights.map((insight, index) => (
          <div key={index} style={{
            padding: '15px',
            backgroundColor: '#f0fdf4',
            borderRadius: '8px',
            borderLeft: '4px solid #22c55e',
            marginBottom: '12px'
          }}>
            <p style={{ margin: 0, lineHeight: '1.6' }}>✓ {insight}</p>
          </div>
        ))}
      </div>

      {/* Recomendações */}
      <div className="card">
        <h2 className="card-title">💡 Recomendações</h2>
        <ul style={{ marginLeft: '20px', lineHeight: '2' }}>
          <li>Continue com o ritmo atual de perda de peso - está saudável</li>
          <li>Considere adicionar mais um dia de treino para acelerar resultados</li>
          <li>Mantenha a ingestão de proteína alta para preservar massa muscular</li>
          <li>Tire fotos semanais para acompanhar mudanças visuais</li>
          <li>Faça medições corporais mensais (cintura, quadril, braço, etc.)</li>
        </ul>
      </div>
    </div>
  );
}

export default ProgressPage;
