import React from 'react';
import { Link } from 'react-router-dom';

function HomePage() {
  return (
    <div className="container">
      <div className="page-hero">
        <h1>Plataforma Inteligente de Saúde</h1>
        <p>
          Transforme sua saúde com planos personalizados de nutrição, treino e bem-estar,
          criados por agentes de IA especializados.
        </p>
        <Link to="/onboarding">
          <button className="btn btn-primary" style={{ marginTop: '30px', fontSize: '18px' }}>
            Começar Agora
          </button>
        </Link>
      </div>

      <div className="features-grid">
        <div className="feature-card">
          <div className="feature-icon">🔍</div>
          <h3>Avaliação de Saúde</h3>
          <p>
            Análise completa de riscos e recomendações baseadas em evidências
            científicas para uma jornada segura.
          </p>
        </div>

        <div className="feature-card">
          <div className="feature-icon">🍎</div>
          <h3>Plano Nutricional</h3>
          <p>
            Planos alimentares personalizados com cálculo preciso de calorias,
            macronutrientes e estimativa de custos.
          </p>
        </div>

        <div className="feature-card">
          <div className="feature-icon">💪</div>
          <h3>Programa de Treino</h3>
          <p>
            Exercícios personalizados adaptados ao seu nível, objetivos e
            equipamentos disponíveis.
          </p>
        </div>

        <div className="feature-card">
          <div className="feature-icon">💰</div>
          <h3>Planejamento Financeiro</h3>
          <p>
            Análise de custos e otimização de orçamento para tornar sua
            jornada de saúde sustentável.
          </p>
        </div>

        <div className="feature-card">
          <div className="feature-icon">📊</div>
          <h3>Acompanhamento</h3>
          <p>
            Rastreie seu progresso com métricas detalhadas, gráficos
            interativos e insights de IA.
          </p>
        </div>

        <div className="feature-card">
          <div className="feature-icon">🤖</div>
          <h3>Inteligência Artificial</h3>
          <p>
            Agentes especializados trabalham juntos para criar seu plano
            de saúde perfeito e personalizado.
          </p>
        </div>
      </div>

      <div className="card" style={{ textAlign: 'center', marginTop: '60px' }}>
        <h2>Como Funciona?</h2>
        <div className="grid grid-3" style={{ marginTop: '40px', textAlign: 'left' }}>
          <div>
            <h3 style={{ color: '#4f46e5' }}>1. Onboarding</h3>
            <p>
              Responda perguntas sobre sua saúde, objetivos, preferências
              alimentares e orçamento disponível.
            </p>
          </div>
          <div>
            <h3 style={{ color: '#4f46e5' }}>2. Análise por IA</h3>
            <p>
              Nossos agentes especializados analisam seus dados e criam
              planos personalizados de nutrição e treino.
            </p>
          </div>
          <div>
            <h3 style={{ color: '#4f46e5' }}>3. Execute e Acompanhe</h3>
            <p>
              Siga seu plano personalizado e acompanhe seu progresso
              com dashboards interativos.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default HomePage;
