# 🏥 Plataforma Inteligente de Saúde - Integração CrewAI

## 🤖 Como Integrar com o Projeto CrewAI Principal

Este guia explica como conectar a aplicação web (na pasta `app/`) com o projeto CrewAI existente (na pasta raiz).

### Arquitetura de Integração

```
CREWAI/
├── CÓDIGO/
│   ├── app/                                    # Aplicação Web MVP
│   │   ├── backend/
│   │   │   └── api/
│   │   │       └── main.py                    # API FastAPI
│   │   └── frontend/                          # Interface React
│   │
│   └── src/intelligent_health_platform_mvp_builder/
│       ├── crew.py                            # Crew CrewAI Original
│       ├── main.py                            # Entry point CrewAI
│       └── config/                            # Configurações YAML
```

### Passo 1: Adicionar Importação do Crew no Backend

Edite `app/backend/api/main.py` e adicione no topo:

```python
import sys
from pathlib import Path

# Adiciona o diretório raiz ao path para importar o crew
root_dir = Path(__file__).parent.parent.parent.parent
sys.path.append(str(root_dir / "src"))

# Importa o crew principal
from intelligent_health_platform_mvp_builder.crew import IntelligentHealthPlatformMvpBuilderCrew
```

### Passo 2: Atualizar Endpoint de Análise Completa

Substitua a função `run_full_crew_analysis` em `app/backend/api/main.py`:

```python
@app.post("/api/crew/run-full-analysis")
async def run_full_crew_analysis(profile: UserProfile):
    """
    Run the full CrewAI analysis with all agents
    """
    try:
        logger.info("Running full crew analysis with CrewAI")
        
        # Prepara inputs para o crew
        inputs = {
            "user_profile": profile.dict()
        }
        
        # Executa o crew
        crew_instance = IntelligentHealthPlatformMvpBuilderCrew()
        result = crew_instance.crew().kickoff(inputs=inputs)
        
        return JSONResponse(content={
            "status": "completed",
            "result": result.raw,
            "user_profile": profile.dict(),
            "message": "Complete health analysis generated successfully"
        })
        
    except Exception as e:
        logger.error(f"Error running crew analysis: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
```

### Passo 3: Criar Endpoints Específicos por Agente

Adicione novos endpoints para cada agente individual:

```python
@app.post("/api/crew/interview")
async def run_health_interviewer(profile: UserProfile):
    """Run health data interviewer agent"""
    try:
        crew = IntelligentHealthPlatformMvpBuilderCrew()
        agent = crew.health_data_interviewer_agent()
        
        prompt = f"Analyze the following user profile and suggest additional questions: {profile.dict()}"
        result = agent.kickoff(prompt)
        
        return JSONResponse(content={"result": result.raw})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/crew/risk-assessment")
async def run_risk_assessment(profile: UserProfile):
    """Run health risk assessment agent"""
    try:
        crew = IntelligentHealthPlatformMvpBuilderCrew()
        agent = crew.health_risk_assessment_agent()
        
        prompt = f"Assess health risks for: {profile.dict()}"
        result = agent.kickoff(prompt)
        
        return JSONResponse(content={"assessment": result.raw})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/crew/nutrition-plan")
async def run_nutrition_planner(profile: UserProfile):
    """Run nutrition planning agent"""
    try:
        crew = IntelligentHealthPlatformMvpBuilderCrew()
        agent = crew.nutrition_planning_agent()
        
        prompt = f"Create nutrition plan for: {profile.dict()}"
        result = agent.kickoff(prompt)
        
        return JSONResponse(content={"plan": result.raw})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/api/crew/training-program")
async def run_training_agent(profile: UserProfile):
    """Run personal training agent"""
    try:
        crew = IntelligentHealthPlatformMvpBuilderCrew()
        agent = crew.personal_training_agent()
        
        prompt = f"Design training program for: {profile.dict()}"
        result = agent.kickoff(prompt)
        
        return JSONResponse(content={"program": result.raw})
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
```

### Passo 4: Atualizar Frontend para Usar Crew Real

Modifique `app/frontend/src/pages/OnboardingPage.js`:

```javascript
const handleSubmit = async (e) => {
  e.preventDefault();
  setLoading(true);

  try {
    const data = {
      ...formData,
      age: parseInt(formData.age),
      height: parseFloat(formData.height),
      weight: parseFloat(formData.weight),
      budget: formData.budget ? parseFloat(formData.budget) : null,
      time_available: formData.time_available ? parseInt(formData.time_available) : null
    };

    // Chama o endpoint do crew completo
    const response = await api.post('/api/crew/run-full-analysis', data);
    
    console.log('Análise completa:', response.data);
    
    // Salva resultado no localStorage para uso nas outras páginas
    localStorage.setItem('crewAnalysis', JSON.stringify(response.data));
    localStorage.setItem('userProfile', JSON.stringify(data));
    
    // Redireciona para o dashboard
    navigate('/dashboard');
  } catch (error) {
    console.error('Erro ao executar análise:', error);
    alert('Erro ao processar análise. Tente novamente.');
  } finally {
    setLoading(false);
  }
};
```

### Passo 5: Processar Resultados do Crew

Crie um hook customizado para processar os resultados:

```javascript
// app/frontend/src/hooks/useCrewData.js
import { useState, useEffect } from 'react';

export const useCrewData = () => {
  const [crewAnalysis, setCrewAnalysis] = useState(null);
  const [userProfile, setUserProfile] = useState(null);

  useEffect(() => {
    const analysis = localStorage.getItem('crewAnalysis');
    const profile = localStorage.getItem('userProfile');
    
    if (analysis) setCrewAnalysis(JSON.parse(analysis));
    if (profile) setUserProfile(JSON.parse(profile));
  }, []);

  return { crewAnalysis, userProfile };
};
```

Use nas páginas:

```javascript
// app/frontend/src/pages/NutritionPage.js
import { useCrewData } from '../hooks/useCrewData';

function NutritionPage() {
  const { crewAnalysis } = useCrewData();
  
  // Parse o resultado do crew para extrair o plano nutricional
  const nutritionPlan = crewAnalysis?.nutrition_plan;
  
  // Renderiza usando os dados reais
}
```

### Passo 6: Configurar Variáveis de Ambiente

Certifique-se de que o `.env` está configurado para ambos os projetos:

```env
# OpenAI
OPENAI_API_KEY=sua-chave-aqui

# Serper (para agentes que fazem pesquisas)
SERPER_API_KEY=sua-chave-aqui

# Supabase
SUPABASE_URL=https://itrouyfcsftruntbibvv.supabase.co
SUPABASE_KEY=sua-chave-aqui

# Modelo LLM
DEFAULT_LLM_MODEL=openai/gpt-4.1-mini
```

### Passo 7: Testando a Integração

1. **Inicie o backend:**
   ```bash
   cd app
   start.bat
   ```

2. **Teste o endpoint do crew:**
   ```bash
   curl -X POST http://localhost:8000/api/crew/run-full-analysis \
     -H "Content-Type: application/json" \
     -d '{
       "name": "John Doe",
       "age": 30,
       "gender": "male",
       "height": 175,
       "weight": 80,
       "activity_level": "moderately_active",
       "goal": "weight_loss"
     }'
   ```

3. **Acesse a documentação interativa:**
   http://localhost:8000/docs

### Estrutura de Resposta Esperada

```json
{
  "status": "completed",
  "result": {
    "health_assessment": {
      "risk_level": "low",
      "bmi": 26.1,
      "recommendations": [...]
    },
    "nutrition_plan": {
      "daily_calories": 1800,
      "macros": {...},
      "meals": [...]
    },
    "training_program": {
      "program_type": "Weight Loss + Muscle Maintenance",
      "schedule": [...]
    },
    "financial_estimate": {
      "monthly_cost": 450.00,
      "breakdown": {...}
    }
  },
  "message": "Complete health analysis generated successfully"
}
```

### Troubleshooting

#### Erro: "Module not found"
```bash
cd app/backend
pip install -r ../../requirements.txt
```

#### Erro: "Crew takes too long"
- Os crews podem levar de 2-5 minutos para executar
- Implemente uma fila de processamento (Celery ou similar)
- Use endpoints assíncronos
- Mostre um loading indicator no frontend

#### Performance

Para melhorar a performance:

1. **Cache de resultados:**
```python
from functools import lru_cache

@lru_cache(maxsize=100)
def get_cached_analysis(profile_hash):
    # Retorna análise cacheada se disponível
    pass
```

2. **Processamento assíncrono:**
```python
from fastapi import BackgroundTasks

@app.post("/api/crew/run-full-analysis")
async def run_analysis(profile: UserProfile, background_tasks: BackgroundTasks):
    # Adiciona tarefa ao background
    background_tasks.add_task(process_crew_analysis, profile)
    return {"status": "processing", "job_id": "..."}
```

3. **Webhook callback:**
- Cliente envia request
- API retorna job_id
- Cliente faz polling em `/api/jobs/{job_id}`
- Quando completo, recebe resultado

---

## 🎯 Próximas Melhorias

1. ✅ Integração completa com CrewAI
2. ⬜ Autenticação de usuários (Supabase Auth)
3. ⬜ Processamento assíncrono de crews
4. ⬜ Notificações em tempo real (WebSockets)
5. ⬜ Upload de fotos de progresso
6. ⬜ Geração de PDFs de relatórios
7. ⬜ Integração com wearables (Fitbit, Apple Watch)
8. ⬜ Chat com agentes individuais
9. ⬜ Gamificação e conquistas
10. ⬜ Deploy em produção

---

**Documentação mantida e atualizada** 🚀
