# 🚀 INÍCIO RÁPIDO - PLATAFORMA DE SAÚDE

## ⚡ Instalação em 3 Passos

### 1️⃣ Configurar Variáveis de Ambiente

Copie `.env.example` para `.env` e adicione suas chaves:

```env
OPENAI_API_KEY=sua-chave-aqui
SUPABASE_URL=https://itrouyfcsftruntbibvv.supabase.co
SUPABASE_KEY=sua-chave-aqui
```

### 2️⃣ Instalar Dependências

```bash
install.bat
```

### 3️⃣ Iniciar Aplicação

```bash
start.bat
```

✅ **Pronto!** Acesse http://localhost:3000

---

## 📱 Funcionalidades Principais

| Página | Descrição |
|--------|-----------|
| 🏠 **Home** | Apresentação e início |
| 📝 **Onboarding** | Cadastro e coleta de dados |
| 📊 **Dashboard** | Visão geral do progresso |
| 🍎 **Nutrição** | Plano alimentar personalizado |
| 💪 **Treino** | Programa de exercícios |
| 📈 **Progresso** | Métricas e evolução |
| 💰 **Financeiro** | Análise de custos |

---

## 🔧 Comandos Úteis

```bash
# Parar aplicação
stop.bat

# Reiniciar backend
cd backend
python -m uvicorn api.main:app --reload

# Reiniciar frontend
cd frontend
npm start

# Ver logs
# Janelas abertas pelo start.bat mostram logs em tempo real
```

---

## 📚 Documentação Completa

- [Guia de Instalação Detalhado](GUIA_INSTALACAO.md)
- [Integração com CrewAI](INTEGRACAO_CREWAI.md)
- [README Principal](README.md)
- [Documentação da API](http://localhost:8000/docs) (após iniciar)

---

## 🆘 Suporte Rápido

**Problema:** Backend não inicia
```bash
cd backend
pip install -r requirements.txt
```

**Problema:** Frontend não inicia  
```bash
cd frontend
npm install
```

**Problema:** Porta em uso
```bash
stop.bat
# Aguarde 5 segundos
start.bat
```

---

## ✨ Tecnologias

- **Backend:** Python + FastAPI + CrewAI
- **Frontend:** React + Axios
- **Database:** Supabase (PostgreSQL)
- **AI:** OpenAI GPT-4

---

**Desenvolvido com ❤️ para transformar saúde com IA**

Para mais detalhes, consulte [README.md](README.md)
