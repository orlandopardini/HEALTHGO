@echo off
echo ========================================
echo  Plataforma Inteligente de Saude - MVP
echo ========================================
echo.

REM Verifica se .env existe
if not exist ".env" (
    echo [ERRO] Arquivo .env nao encontrado!
    echo Por favor, execute install.bat primeiro e configure o arquivo .env
    pause
    exit /b 1
)

echo Iniciando a Plataforma de Saude...
echo.

REM Cria diretório de logs se não existir
if not exist "logs" mkdir logs

REM Inicia o backend em uma nova janela
echo [1/2] Iniciando backend API...
start "Health Platform - Backend" cmd /k "cd backend && python -m uvicorn api.main:app --reload --port 8000"

REM Aguarda alguns segundos para o backend iniciar
timeout /t 5 /nobreak >nul

REM Inicia o frontend em uma nova janela
echo [2/2] Iniciando frontend React...
start "Health Platform - Frontend" cmd /k "cd frontend && npm start"

echo.
echo ========================================
echo  APLICACAO INICIADA!
echo ========================================
echo.
echo Backend API: http://localhost:8000
echo Frontend Web: http://localhost:3000
echo Documentacao API: http://localhost:8000/docs
echo.
echo Para parar a aplicacao, feche as janelas do backend e frontend
echo.
echo Aguardando inicializacao completa...
timeout /t 10 /nobreak >nul

REM Abre o navegador automaticamente
start http://localhost:3000

echo.
echo Aplicacao pronta! O navegador foi aberto automaticamente.
echo.
pause
