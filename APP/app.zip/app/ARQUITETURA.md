# 🏗️ Arquitetura da Plataforma Inteligente de Saúde

## 📐 Visão Geral da Arquitetura

```
┌─────────────────────────────────────────────────────────────┐
│                     USUÁRIO FINAL                            │
│                   (Navegador Web)                            │
└────────────────────┬────────────────────────────────────────┘
                     │
                     │ HTTP/HTTPS
                     ▼
┌─────────────────────────────────────────────────────────────┐
│                  FRONTEND (React)                            │
│                  Port: 3000                                  │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  Pages                                               │   │
│  │  - HomePage                                          │   │
│  │  - OnboardingPage                                    │   │
│  │  - DashboardPage                                     │   │
│  │  - NutritionPage, TrainingPage, etc.                │   │
│  └─────────────────────────────────────────────────────┘   │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  Services                                            │   │
│  │  - api.js (Axios - integração com backend)          │   │
│  └─────────────────────────────────────────────────────┘   │
└────────────────────┬────────────────────────────────────────┘
                     │
                     │ REST API (JSON)
                     ▼
┌─────────────────────────────────────────────────────────────┐
│                  BACKEND (FastAPI)                           │
│                  Port: 8000                                  │
│  ┌─────────────────────────────────────────────────────┐   │
│  │  API Endpoints                                       │   │
│  │  - /api/users/*                                      │   │
│  │  - /api/assessment/*                                 │   │
│  │  - /api/nutrition/*                                  │   │
│  │  - /api/training/*                                   │   │
│  │  - /api/progress/*                                   │   │
│  │  - /api/financial/*                                  │   │
│  │  - /api/crew/* (CrewAI integration)                 │   │
│  └────────────┬────────────────────────────────────────┘   │
│               │                                              │
│               ├─► CrewAI Integration Layer                  │
│               │   - crew_integration.py                     │
│               │                                              │
│               ├─► Database Layer                            │
│               │   - supabase_client.py                      │
│               │                                              │
│               └─► Business Logic                            │
│                   - Health calculations                     │
│                   - Data validation                         │
└────────────────────┬───────────────┬────────────────────────┘
                     │               │
                     │               │
        ┌────────────▼──────┐   ┌───▼──────────────┐
        │                   │   │                   │
        │  CREWAI AGENTS    │   │  SUPABASE DB      │
        │  (AI Processing)  │   │  (PostgreSQL)     │
        │                   │   │                   │
        └───────────────────┘   └───────────────────┘
                │                        │
                │                        │
                ▼                        ▼
        ┌───────────────┐       ┌────────────────┐
        │  OPENAI API   │       │  Data Storage  │
        │  (LLM)        │       │  - Users       │
        │               │       │  - Profiles    │
        └───────────────┘       │  - Plans       │
                                │  - Progress    │
                                └────────────────┘
```

## 🔄 Fluxo de Dados

### 1. Onboarding de Usuário

```
User Input → React Form → POST /api/users/onboard
                                    ↓
                            FastAPI Validation
                                    ↓
                            CrewAI Agents Triggered
                                    ↓
            ┌───────────────────────┴───────────────────────┐
            ▼                       ▼                       ▼
    Health Interviewer    Risk Assessment        Nutrition Planner
         Agent                Agent                    Agent
            │                       │                       │
            └───────────────────────┴───────────────────────┘
                                    ↓
                            Results Aggregation
                                    ↓
                            Store in Supabase
                                    ↓
                            Return to Frontend
                                    ↓
                            Display Dashboard
```

### 2. Criação de Plano Nutricional

```
Dashboard → Click "Ver Nutrição" → GET /api/nutrition/plan
                                            ↓
                                    Fetch from Database
                                            │
                                            │ (if not exists)
                                            ▼
                                    Trigger Nutrition Agent
                                            ↓
                                    Generate Plan (AI)
                                            ↓
                                    Store in Database
                                            ↓
                                    Return JSON
                                            ↓
                                    Render in React
```

### 3. Rastreamento de Progresso

```
User Logs Data → POST /api/progress/{user_id}
                            ↓
                    Store in Database
                            ↓
                    Trigger Progress Agent
                            ↓
                    Calculate Metrics
                    Generate Insights (AI)
                            ↓
                    Update Dashboard
                    Send Notifications
```

## 🗂️ Estrutura de Camadas

### Frontend (Presentation Layer)

```
frontend/
├── public/              # Static assets
├── src/
│   ├── components/      # Reusable UI components
│   │   ├── Header.js
│   │   └── Footer.js
│   │
│   ├── pages/          # Route pages
│   │   ├── HomePage.js
│   │   ├── OnboardingPage.js
│   │   ├── DashboardPage.js
│   │   ├── NutritionPage.js
│   │   ├── TrainingPage.js
│   │   ├── ProgressPage.js
│   │   └── FinancialPage.js
│   │
│   ├── services/       # API integrations
│   │   └── api.js      # Axios instance
│   │
│   ├── styles/         # CSS files
│   │   ├── index.css
│   │   └── App.css
│   │
│   ├── App.js          # Main app component
│   └── index.js        # Entry point
│
└── package.json        # Dependencies
```

### Backend (API Layer)

```
backend/
├── api/
│   ├── __init__.py
│   └── main.py              # FastAPI app + endpoints
│
├── database/
│   ├── __init__.py
│   ├── supabase_client.py   # DB connection
│   └── setup_database.py    # DB initialization
│
├── crew_integration.py      # CrewAI service layer
└── requirements.txt         # Python dependencies
```

### CrewAI Layer (Business Logic)

```
src/intelligent_health_platform_mvp_builder/
├── config/
│   ├── agents.yaml          # Agent definitions
│   └── tasks.yaml           # Task definitions
│
├── crew.py                  # Crew orchestration
└── main.py                  # CLI entry point
```

## 🔐 Segurança

### Autenticação (Futuro)

```
┌─────────┐
│ User    │
└────┬────┘
     │ Login Credentials
     ▼
┌─────────────────┐
│ Supabase Auth   │
└────┬────────────┘
     │ JWT Token
     ▼
┌─────────────────┐
│ Frontend        │
│ (stores token)  │
└────┬────────────┘
     │ API Requests + Bearer Token
     ▼
┌─────────────────┐
│ Backend         │
│ (validates JWT) │
└─────────────────┘
```

### Dados Sensíveis

- **Variáveis de Ambiente:** `.env` (nunca committed)
- **API Keys:** Armazenadas em variáveis de ambiente
- **Senhas:** Hashed com bcrypt (quando implementado)
- **Database:** Row Level Security (RLS) no Supabase

## 📊 Modelo de Dados (Supabase)

### Entidades Principais

```
┌──────────┐         ┌─────────────────┐
│  users   │────1:1──│ user_profiles   │
└──────────┘         └─────────────────┘
     │
     │ 1:N
     │
     ├─────────► health_assessments
     │
     ├─────────► nutrition_plans
     │
     ├─────────► training_programs
     │
     ├─────────► progress_entries
     │
     ├─────────► financial_plans
     │
     ├─────────► workout_logs
     │
     └─────────► meal_logs
```

### Schemas

**users**
- id (UUID, PK)
- email (String, Unique)
- name (String)
- created_at, updated_at

**user_profiles**
- id (UUID, PK)
- user_id (UUID, FK)
- age, gender, height, weight
- activity_level, goal
- dietary_restrictions (JSONB)
- medical_conditions (JSONB)
- budget, equipment_available
- created_at, updated_at

**nutrition_plans**
- id (UUID, PK)
- user_id (UUID, FK)
- daily_calories (Integer)
- macros (JSONB)
- meal_plan (JSONB)
- estimated_cost (Decimal)
- valid_from, valid_to

**training_programs**
- id (UUID, PK)
- user_id (UUID, FK)
- program_type (String)
- weekly_schedule (JSONB)
- exercises (JSONB)
- duration_weeks (Integer)

## 🤖 CrewAI Integration

### Agentes Disponíveis

| Agente | Responsabilidade | Ferramentas |
|--------|------------------|-------------|
| **Health Interviewer** | Coleta de dados | - |
| **Risk Assessment** | Análise de riscos | SerperDevTool |
| **Nutrition Planner** | Planos nutricionais | SerperDevTool |
| **Training Agent** | Programas de treino | SerperDevTool |
| **Financial Planner** | Análise de custos | SerperDevTool |
| **Progress Tracker** | Métricas e insights | - |
| **Frontend Developer** | Geração de UI | - |
| **Database Manager** | Gerenciamento BD | - |

### Processo de Execução

```python
# Sequential Process
crew = Crew(
    agents=[...],
    tasks=[...],
    process=Process.sequential
)

# Task Dependencies
task2 = Task(
    description="...",
    agent=agent2,
    context=[task1]  # Depends on task1 output
)

# Execution
result = crew.kickoff(inputs={"user_profile": {...}})
```

## 🚀 Deploy

### Desenvolvimento Local

```bash
# Backend
cd backend
uvicorn api.main:app --reload --port 8000

# Frontend
cd frontend
npm start
```

### Produção (Futuro)

**Frontend:** Vercel / Netlify
```bash
npm run build
# Deploy /build folder
```

**Backend:** Railway / Render / Fly.io
```bash
docker build -t health-platform-api .
docker push ...
```

**Database:** Supabase Cloud (já configurado)

## 📈 Escalabilidade

### Melhorias Futuras

1. **Caching**
   - Redis para resultados de crew
   - CDN para assets frontend

2. **Queue System**
   - Celery para processamento assíncrono
   - RabbitMQ/Redis como message broker

3. **Load Balancing**
   - Múltiplas instâncias FastAPI
   - NGINX como reverse proxy

4. **Monitoring**
   - Sentry para error tracking
   - DataDog/New Relic para APM
   - Prometheus + Grafana para métricas

## 🧪 Testing

```
app/
├── backend/
│   └── tests/
│       ├── test_api.py
│       ├── test_crew_integration.py
│       └── test_database.py
│
└── frontend/
    └── src/
        └── __tests__/
            ├── HomePage.test.js
            ├── OnboardingPage.test.js
            └── api.test.js
```

---

**Documentação mantida e atualizada** 🏗️
