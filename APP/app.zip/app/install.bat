@echo off
echo ========================================
echo  Instalador - Plataforma de Saude
echo ========================================
echo.

REM Verifica se Python esta instalado
python --version >nul 2>&1
if errorlevel 1 (
    echo [ERRO] Python nao encontrado. Por favor, instale Python 3.10+ primeiro.
    echo Baixe em: https://www.python.org/downloads/
    pause
    exit /b 1
)

REM Verifica se Node.js esta instalado
node --version >nul 2>&1
if errorlevel 1 (
    echo [ERRO] Node.js nao encontrado. Por favor, instale Node.js 16+ primeiro.
    echo Baixe em: https://nodejs.org/
    pause
    exit /b 1
)

echo [OK] Python e Node.js encontrados
echo.

REM Cria diretório de logs
if not exist "logs" mkdir logs

REM Instala dependências Python do backend
echo [1/4] Instalando dependencias do backend...
cd backend
pip install -r requirements.txt
if errorlevel 1 (
    echo [ERRO] Falha ao instalar dependencias Python
    pause
    exit /b 1
)
cd ..

echo [OK] Dependencias do backend instaladas
echo.

REM Instala dependências do frontend
echo [2/4] Instalando dependencias do frontend...
cd frontend
call npm install
if errorlevel 1 (
    echo [ERRO] Falha ao instalar dependencias Node.js
    pause
    exit /b 1
)
cd ..

echo [OK] Dependencias do frontend instaladas
echo.

REM Copia arquivo de ambiente se não existir
echo [3/4] Configurando variaveis de ambiente...
if not exist ".env" (
    if exist ".env.example" (
        copy .env.example .env
        echo [ATENCAO] Arquivo .env criado. Por favor, configure suas chaves de API!
        echo Edite o arquivo .env com suas credenciais.
    ) else (
        echo [AVISO] Arquivo .env.example nao encontrado
    )
) else (
    echo [OK] Arquivo .env ja existe
)
echo.

REM Setup do banco de dados
echo [4/4] Configurando banco de dados Supabase...
cd backend
python database/setup_database.py
if errorlevel 1 (
    echo [AVISO] Erro ao configurar banco de dados. Verifique suas credenciais do Supabase.
    echo Voce pode executar manualmente: python backend/database/setup_database.py
) else (
    echo [OK] Banco de dados configurado
)
cd ..

echo.
echo ========================================
echo  INSTALACAO CONCLUIDA!
echo ========================================
echo.
echo Proximos passos:
echo 1. Configure suas chaves de API no arquivo .env
echo 2. Execute start.bat para iniciar a aplicacao
echo.
pause
