"""
CrewAI Integration Module

This module provides integration between the web API and CrewAI agents.
"""

import sys
from pathlib import Path
from typing import Dict, Any, Optional
import logging

logger = logging.getLogger(__name__)

# Add the project root to Python path
root_dir = Path(__file__).parent.parent.parent
sys.path.append(str(root_dir / "src"))

try:
    from intelligent_health_platform_mvp_builder.crew import IntelligentHealthPlatformMvpBuilderCrew
    CREW_AVAILABLE = True
except ImportError as e:
    logger.warning(f"CrewAI crew not available: {e}")
    CREW_AVAILABLE = False


class CrewService:
    """Service for interacting with CrewAI agents"""
    
    def __init__(self):
        self.crew_available = CREW_AVAILABLE
    
    def is_available(self) -> bool:
        """Check if CrewAI crew is available"""
        return self.crew_available
    
    def run_full_analysis(self, user_profile: Dict[str, Any]) -> Dict[str, Any]:
        """
        Run full health analysis with all CrewAI agents
        
        Args:
            user_profile: User profile data
            
        Returns:
            Analysis results from all agents
        """
        if not self.crew_available:
            raise RuntimeError("CrewAI crew is not available")
        
        try:
            logger.info("Starting full CrewAI analysis")
            
            crew_instance = IntelligentHealthPlatformMvpBuilderCrew()
            inputs = {"user_profile": user_profile}
            
            result = crew_instance.crew().kickoff(inputs=inputs)
            
            return {
                "status": "completed",
                "result": result.raw,
                "token_usage": result.token_usage if hasattr(result, 'token_usage') else None,
                "tasks_output": [task.raw for task in result.tasks_output] if hasattr(result, 'tasks_output') else []
            }
            
        except Exception as e:
            logger.error(f"Error running crew analysis: {str(e)}")
            raise
    
    def run_individual_agent(self, agent_name: str, prompt: str) -> Dict[str, Any]:
        """
        Run a single CrewAI agent
        
        Args:
            agent_name: Name of the agent to run
            prompt: Input prompt for the agent
            
        Returns:
            Agent response
        """
        if not self.crew_available:
            raise RuntimeError("CrewAI crew is not available")
        
        try:
            crew_instance = IntelligentHealthPlatformMvpBuilderCrew()
            
            # Get the agent method
            agent_method = getattr(crew_instance, agent_name, None)
            if not agent_method:
                raise ValueError(f"Agent '{agent_name}' not found")
            
            agent = agent_method()
            result = agent.kickoff(prompt)
            
            return {
                "status": "completed",
                "result": result.raw,
                "agent": agent_name
            }
            
        except Exception as e:
            logger.error(f"Error running agent {agent_name}: {str(e)}")
            raise


# Singleton instance
_crew_service = None

def get_crew_service() -> CrewService:
    """Get or create CrewService instance"""
    global _crew_service
    if _crew_service is None:
        _crew_service = CrewService()
    return _crew_service
