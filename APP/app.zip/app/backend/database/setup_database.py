"""
Supabase Database Setup Script

This script creates all necessary tables and inserts mock data
into the Supabase PostgreSQL database.
"""

import os
import sys
from dotenv import load_dotenv
from supabase import create_client, Client
import logging

# Load environment variables
load_dotenv()

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

# Supabase configuration
SUPABASE_URL = os.getenv("SUPABASE_URL")
SUPABASE_KEY = os.getenv("SUPABASE_SERVICE_ROLE_KEY") or os.getenv("SUPABASE_KEY")

if not SUPABASE_URL or not SUPABASE_KEY:
    logger.error("SUPABASE_URL and SUPABASE_KEY must be set in .env file")
    sys.exit(1)

# Initialize Supabase client
supabase: Client = create_client(SUPABASE_URL, SUPABASE_KEY)

# SQL Schema for Health Platform
SQL_SCHEMA = """
-- Users table
CREATE TABLE IF NOT EXISTS users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email VARCHAR(255) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- User Health Profiles
CREATE TABLE IF NOT EXISTS user_profiles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    age INTEGER NOT NULL,
    gender VARCHAR(50),
    height DECIMAL(5,2),
    weight DECIMAL(5,2),
    activity_level VARCHAR(50),
    goal VARCHAR(100),
    dietary_restrictions JSONB DEFAULT '[]',
    medical_conditions JSONB DEFAULT '[]',
    budget DECIMAL(10,2),
    equipment_available JSONB DEFAULT '[]',
    time_available INTEGER,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Health Assessments
CREATE TABLE IF NOT EXISTS health_assessments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    risk_level VARCHAR(50),
    bmi DECIMAL(5,2),
    recommendations JSONB DEFAULT '[]',
    contraindications JSONB DEFAULT '[]',
    assessment_date TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Nutrition Plans
CREATE TABLE IF NOT EXISTS nutrition_plans (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    daily_calories INTEGER,
    macros JSONB,
    meal_plan JSONB,
    estimated_cost DECIMAL(10,2),
    valid_from DATE,
    valid_to DATE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Training Programs
CREATE TABLE IF NOT EXISTS training_programs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    program_type VARCHAR(100),
    weekly_schedule JSONB,
    exercises JSONB,
    duration_weeks INTEGER,
    valid_from DATE,
    valid_to DATE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Progress Tracking
CREATE TABLE IF NOT EXISTS progress_entries (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    entry_date DATE NOT NULL,
    weight DECIMAL(5,2),
    body_fat_percentage DECIMAL(5,2),
    measurements JSONB,
    notes TEXT,
    photos JSONB DEFAULT '[]',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Financial Plans
CREATE TABLE IF NOT EXISTS financial_plans (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    monthly_costs JSONB,
    total_monthly DECIMAL(10,2),
    budget_status VARCHAR(50),
    recommendations JSONB DEFAULT '[]',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Workout Logs
CREATE TABLE IF NOT EXISTS workout_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    training_program_id UUID REFERENCES training_programs(id),
    workout_date DATE NOT NULL,
    exercises_completed JSONB,
    duration_minutes INTEGER,
    calories_burned INTEGER,
    notes TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Meal Logs
CREATE TABLE IF NOT EXISTS meal_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    nutrition_plan_id UUID REFERENCES nutrition_plans(id),
    meal_date DATE NOT NULL,
    meal_type VARCHAR(50),
    foods JSONB,
    total_calories INTEGER,
    macros JSONB,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create indexes for performance
CREATE INDEX IF NOT EXISTS idx_user_profiles_user_id ON user_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_health_assessments_user_id ON health_assessments(user_id);
CREATE INDEX IF NOT EXISTS idx_nutrition_plans_user_id ON nutrition_plans(user_id);
CREATE INDEX IF NOT EXISTS idx_training_programs_user_id ON training_programs(user_id);
CREATE INDEX IF NOT EXISTS idx_progress_entries_user_id ON progress_entries(user_id);
CREATE INDEX IF NOT EXISTS idx_workout_logs_user_id ON workout_logs(user_id);
CREATE INDEX IF NOT EXISTS idx_meal_logs_user_id ON meal_logs(user_id);
"""

# Mock data for testing
MOCK_USERS = [
    {
        "email": "john.doe@example.com",
        "name": "John Doe"
    },
    {
        "email": "jane.smith@example.com",
        "name": "Jane Smith"
    },
    {
        "email": "mike.wilson@example.com",
        "name": "Mike Wilson"
    }
]

def setup_database():
    """Setup database schema and insert mock data"""
    
    logger.info("Starting database setup...")
    
    try:
        # Note: Direct SQL execution requires service role key
        # For table creation, you should use Supabase Dashboard SQL Editor
        # or use the SQL API directly
        
        logger.info("""
        =========================================================
        DATABASE SETUP INSTRUCTIONS
        =========================================================
        
        Please run the following SQL in your Supabase SQL Editor:
        (Dashboard -> SQL Editor -> New Query)
        
        The SQL schema has been saved to: database_schema.sql
        
        Copy and paste the contents of that file into the SQL Editor
        and click 'Run' to create all tables.
        
        =========================================================
        """)
        
        # Save SQL to file
        with open("database_schema.sql", "w") as f:
            f.write(SQL_SCHEMA)
        
        logger.info("SQL schema saved to database_schema.sql")
        
        # Try to insert mock users (if tables exist)
        try:
            for user in MOCK_USERS:
                result = supabase.table("users").insert(user).execute()
                logger.info(f"Inserted mock user: {user['name']}")
        except Exception as e:
            logger.warning(f"Could not insert mock users: {str(e)}")
            logger.info("This is normal if tables don't exist yet")
        
        logger.info("Database setup complete!")
        
    except Exception as e:
        logger.error(f"Error during database setup: {str(e)}")
        return False
    
    return True

if __name__ == "__main__":
    success = setup_database()
    if not success:
        sys.exit(1)
