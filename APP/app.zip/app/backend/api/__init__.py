# API Backend initialization
