"""
FastAPI Backend for Intelligent Health Platform MVP

This is the main API application that integrates CrewAI agents
and provides RESTful endpoints for the frontend.
"""

from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import os
from dotenv import load_dotenv
import logging

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title="Intelligent Health Platform API",
    version="1.0.0",
    description="API for personalized health, nutrition, and fitness planning",
    docs_url="/docs",
    redoc_url="/redoc"
)

# Configure CORS
origins = os.getenv("ALLOWED_ORIGINS", "http://localhost:3000").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ============================================================================
# Pydantic Models
# ============================================================================

class HealthCheck(BaseModel):
    status: str
    version: str
    message: str

class UserProfile(BaseModel):
    name: str
    age: int
    gender: str
    height: float
    weight: float
    activity_level: str
    goal: str
    dietary_restrictions: Optional[List[str]] = []
    medical_conditions: Optional[List[str]] = []
    budget: Optional[float] = None
    equipment_available: Optional[List[str]] = []
    time_available: Optional[int] = None

class NutritionPlan(BaseModel):
    user_id: Optional[str] = None
    daily_calories: int
    macros: Dict[str, float]
    meal_plan: List[Dict[str, Any]]
    estimated_cost: float

class TrainingPlan(BaseModel):
    user_id: Optional[str] = None
    program_type: str
    weekly_schedule: List[Dict[str, Any]]
    exercises: List[Dict[str, Any]]
    duration_weeks: int

class HealthAssessment(BaseModel):
    user_id: Optional[str] = None
    risk_level: str
    bmi: float
    recommendations: List[str]
    contraindications: Optional[List[str]] = []

class ProgressReport(BaseModel):
    user_id: str
    period: str
    metrics: Dict[str, Any]
    achievements: List[str]
    insights: List[str]

# ============================================================================
# API Endpoints
# ============================================================================

@app.get("/", response_model=HealthCheck)
async def root():
    """Root endpoint - Health check"""
    return {
        "status": "healthy",
        "version": "1.0.0",
        "message": "Intelligent Health Platform API is running"
    }

@app.get("/health", response_model=HealthCheck)
async def health_check():
    """Health check endpoint"""
    return {
        "status": "healthy",
        "version": "1.0.0",
        "message": "All systems operational"
    }

# ============================================================================
# User Profile Endpoints
# ============================================================================

@app.post("/api/users/onboard")
async def onboard_user(profile: UserProfile):
    """
    Onboard a new user by collecting their health profile
    and triggering the health assessment crew
    """
    try:
        logger.info(f"Onboarding new user: {profile.name}")
        
        # TODO: Integrate with CrewAI health data interviewer agent
        # For now, return mock response
        
        user_data = {
            "user_id": f"user_{hash(profile.name)}",
            "profile": profile.dict(),
            "status": "onboarded",
            "message": "Profile created successfully"
        }
        
        return JSONResponse(content=user_data)
        
    except Exception as e:
        logger.error(f"Error onboarding user: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/api/users/{user_id}")
async def get_user_profile(user_id: str):
    """Get user profile by ID"""
    try:
        # TODO: Fetch from Supabase
        return {
            "user_id": user_id,
            "message": "User profile endpoint"
        }
    except Exception as e:
        raise HTTPException(status_code=404, detail="User not found")

# ============================================================================
# Health Assessment Endpoints
# ============================================================================

@app.post("/api/assessment/analyze")
async def analyze_health_risk(profile: UserProfile):
    """
    Analyze health risk based on user profile
    using the health risk assessment agent
    """
    try:
        logger.info(f"Analyzing health risk for user")
        
        # Calculate BMI
        height_m = profile.height / 100
        bmi = profile.weight / (height_m ** 2)
        
        # Determine risk level (simplified logic)
        if bmi < 18.5:
            risk_level = "moderate"
        elif 18.5 <= bmi < 25:
            risk_level = "low"
        elif 25 <= bmi < 30:
            risk_level = "moderate"
        else:
            risk_level = "high"
        
        assessment = {
            "risk_level": risk_level,
            "bmi": round(bmi, 2),
            "recommendations": [
                "Consult with healthcare provider before starting new program",
                "Start with moderate intensity exercises",
                "Monitor progress regularly"
            ],
            "contraindications": []
        }
        
        return JSONResponse(content=assessment)
        
    except Exception as e:
        logger.error(f"Error analyzing health risk: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# ============================================================================
# Nutrition Planning Endpoints
# ============================================================================

@app.post("/api/nutrition/plan")
async def create_nutrition_plan(profile: UserProfile):
    """
    Create personalized nutrition plan
    using the nutrition planning agent
    """
    try:
        logger.info("Creating nutrition plan")
        
        # TODO: Integrate with CrewAI nutrition planning agent
        
        # Mock response
        plan = {
            "daily_calories": 2000,
            "macros": {
                "protein": 150,
                "carbs": 200,
                "fats": 65
            },
            "meal_plan": [
                {
                    "meal": "Breakfast",
                    "time": "08:00",
                    "foods": ["Oatmeal", "Banana", "Protein shake"],
                    "calories": 450
                },
                {
                    "meal": "Lunch",
                    "time": "13:00",
                    "foods": ["Grilled chicken", "Brown rice", "Vegetables"],
                    "calories": 600
                },
                {
                    "meal": "Dinner",
                    "time": "19:00",
                    "foods": ["Salmon", "Sweet potato", "Salad"],
                    "calories": 550
                }
            ],
            "estimated_cost": 350.00
        }
        
        return JSONResponse(content=plan)
        
    except Exception as e:
        logger.error(f"Error creating nutrition plan: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# ============================================================================
# Training Program Endpoints
# ============================================================================

@app.post("/api/training/program")
async def create_training_program(profile: UserProfile):
    """
    Create personalized training program
    using the personal training agent
    """
    try:
        logger.info("Creating training program")
        
        # TODO: Integrate with CrewAI training agent
        
        # Mock response
        program = {
            "program_type": "Strength & Conditioning",
            "duration_weeks": 12,
            "weekly_schedule": [
                {
                    "day": "Monday",
                    "focus": "Upper Body",
                    "duration": 60,
                    "exercises": 6
                },
                {
                    "day": "Wednesday",
                    "focus": "Lower Body",
                    "duration": 60,
                    "exercises": 6
                },
                {
                    "day": "Friday",
                    "focus": "Full Body",
                    "duration": 45,
                    "exercises": 8
                }
            ],
            "exercises": [
                {
                    "name": "Bench Press",
                    "sets": 4,
                    "reps": "8-12",
                    "rest": "90s"
                },
                {
                    "name": "Squats",
                    "sets": 4,
                    "reps": "8-12",
                    "rest": "120s"
                }
            ]
        }
        
        return JSONResponse(content=program)
        
    except Exception as e:
        logger.error(f"Error creating training program: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# ============================================================================
# Progress Tracking Endpoints
# ============================================================================

@app.get("/api/progress/{user_id}")
async def get_progress(user_id: str, period: str = "week"):
    """Get user progress report"""
    try:
        # TODO: Integrate with progress tracking agent
        
        report = {
            "user_id": user_id,
            "period": period,
            "metrics": {
                "weight": 75.5,
                "body_fat": 18.2,
                "calories_avg": 1950,
                "workouts_completed": 3,
                "adherence_rate": 85
            },
            "achievements": [
                "Completed 3 workouts this week",
                "Met daily calorie target 5 days"
            ],
            "insights": [
                "Good consistency with nutrition",
                "Consider adding one more workout session"
            ]
        }
        
        return JSONResponse(content=report)
        
    except Exception as e:
        logger.error(f"Error getting progress: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# ============================================================================
# Financial Planning Endpoints
# ============================================================================

@app.post("/api/financial/estimate")
async def estimate_costs(profile: UserProfile):
    """
    Estimate costs for health journey
    using the financial planning agent
    """
    try:
        # TODO: Integrate with financial planning agent
        
        estimate = {
            "monthly_costs": {
                "nutrition": 350.00,
                "gym_membership": 50.00,
                "supplements": 80.00,
                "equipment": 0.00
            },
            "total_monthly": 480.00,
            "budget_status": "within_budget" if profile.budget and profile.budget >= 480 else "needs_optimization",
            "recommendations": [
                "Consider home workouts to save on gym fees",
                "Buy groceries in bulk for better prices"
            ]
        }
        
        return JSONResponse(content=estimate)
        
    except Exception as e:
        logger.error(f"Error estimating costs: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# ============================================================================
# CrewAI Integration Endpoints
# ============================================================================

@app.post("/api/crew/run-full-analysis")
async def run_full_crew_analysis(profile: UserProfile):
    """
    Run the full CrewAI analysis with all agents
    This endpoint triggers the complete health platform crew
    """
    try:
        logger.info("Running full crew analysis")
        
        # TODO: Import and run the actual CrewAI crew from the main project
        # from intelligent_health_platform_mvp_builder.crew import IntelligentHealthPlatformMvpBuilderCrew
        
        # For now, return aggregated mock data
        result = {
            "status": "completed",
            "user_profile": profile.dict(),
            "health_assessment": {
                "risk_level": "low",
                "bmi": 22.5
            },
            "nutrition_plan": {
                "daily_calories": 2000,
                "created": True
            },
            "training_program": {
                "program_type": "Strength & Conditioning",
                "created": True
            },
            "financial_estimate": {
                "monthly_cost": 480.00,
                "within_budget": True
            },
            "message": "Complete health analysis generated successfully"
        }
        
        return JSONResponse(content=result)
        
    except Exception as e:
        logger.error(f"Error running crew analysis: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

# ============================================================================
# Error Handlers
# ============================================================================

@app.exception_handler(404)
async def not_found_handler(request, exc):
    return JSONResponse(
        status_code=404,
        content={"message": "Resource not found"}
    )

@app.exception_handler(500)
async def internal_error_handler(request, exc):
    return JSONResponse(
        status_code=500,
        content={"message": "Internal server error"}
    )

if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("BACKEND_PORT", 8000))
    uvicorn.run(app, host="0.0.0.0", port=port, reload=True)
