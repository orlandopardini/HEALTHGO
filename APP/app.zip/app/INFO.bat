@echo off
cls
echo.
echo ========================================================================
echo               PLATAFORMA INTELIGENTE DE SAUDE - MVP
echo                    Bem-vindo ao Sistema!
echo ========================================================================
echo.
echo Este e um sistema completo de saude com IA que inclui:
echo.
echo   [✓] Interface Web Profissional (React)
echo   [✓] API Backend Completa (FastAPI)
echo   [✓] Integracao com CrewAI
echo   [✓] Banco de Dados (Supabase)
echo   [✓] Scripts de Instalacao Automatica
echo.
echo ========================================================================
echo                         INICIO RAPIDO
echo ========================================================================
echo.
echo 1. Configure o arquivo .env com suas chaves de API
echo    - Copie .env.example para .env
echo    - Adicione sua OPENAI_API_KEY
echo    - Adicione suas credenciais do SUPABASE
echo.
echo 2. Execute: install.bat
echo    - Instala todas as dependencias automaticamente
echo.
echo 3. Execute: start.bat
echo    - Inicia backend e frontend
echo    - Abre automaticamente no navegador
echo.
echo ========================================================================
echo                      DOCUMENTACAO DISPONIVEL
echo ========================================================================
echo.
echo   README.md              - Visao geral do projeto
echo   QUICKSTART.md          - Inicio rapido
echo   GUIA_INSTALACAO.md     - Guia detalhado de instalacao
echo   INTEGRACAO_CREWAI.md   - Como integrar com CrewAI
echo   ARQUITETURA.md         - Documentacao da arquitetura
echo.
echo ========================================================================
echo                      ESTRUTURA DO PROJETO
echo ========================================================================
echo.
echo app/
echo   ├── backend/               Backend FastAPI + CrewAI
echo   │   ├── api/               Endpoints REST
echo   │   ├── database/          Integracao Supabase
echo   │   └── crew_integration.py
echo   │
echo   ├── frontend/              Aplicacao React
echo   │   ├── src/
echo   │   │   ├── components/    Header, Footer
echo   │   │   ├── pages/         7 paginas completas
echo   │   │   ├── services/      Integracao com API
echo   │   │   └── styles/        CSS profissional
echo   │   └── public/
echo   │
echo   ├── install.bat            Instalador automatico
echo   ├── start.bat              Inicializador
echo   └── stop.bat               Para a aplicacao
echo.
echo ========================================================================
echo                         RECURSOS IMPLEMENTADOS
echo ========================================================================
echo.
echo PAGINAS DO FRONTEND:
echo   [✓] Home Page              - Landing page com features
echo   [✓] Onboarding             - Formulario de cadastro completo
echo   [✓] Dashboard              - Visao geral e metricas
echo   [✓] Nutricao               - Plano alimentar detalhado
echo   [✓] Treino                 - Programa de exercicios
echo   [✓] Progresso              - Graficos e estatisticas
echo   [✓] Financeiro             - Analise de custos
echo.
echo API ENDPOINTS:
echo   [✓] POST /api/users/onboard
echo   [✓] GET  /api/users/{user_id}
echo   [✓] POST /api/assessment/analyze
echo   [✓] POST /api/nutrition/plan
echo   [✓] POST /api/training/program
echo   [✓] GET  /api/progress/{user_id}
echo   [✓] POST /api/financial/estimate
echo   [✓] POST /api/crew/run-full-analysis
echo.
echo INTEGRACAO CREWAI:
echo   [✓] 8 Agentes especializados
echo   [✓] Integracao completa com crew existente
echo   [✓] Service layer para comunicacao
echo   [✓] Endpoints para analise individual e completa
echo.
echo BANCO DE DADOS:
echo   [✓] Schema completo (9 tabelas)
echo   [✓] Cliente Supabase configurado
echo   [✓] Script de setup automatico
echo   [✓] Suporte a dados mockados para testes
echo.
echo ========================================================================
echo                          PROXIMOS PASSOS
echo ========================================================================
echo.
echo 1. Leia QUICKSTART.md para comecar rapidamente
echo 2. Configure suas chaves de API no arquivo .env
echo 3. Execute install.bat
echo 4. Execute start.bat
echo 5. Acesse http://localhost:3000
echo.
echo Para suporte detalhado, consulte GUIA_INSTALACAO.md
echo.
echo ========================================================================
echo                    Desenvolvido com CrewAI
echo                      orlando.gardezani
echo ========================================================================
echo.
pause
