@echo off
echo ========================================
echo  Stop - Plataforma de Saude
echo ========================================
echo.

echo Encerrando processos da aplicacao...

REM Encerra processos na porta 3000 (Frontend)
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :3000') do (
    taskkill /F /PID %%a 2>nul
)

REM Encerra processos na porta 8000 (Backend)
for /f "tokens=5" %%a in ('netstat -aon ^| findstr :8000') do (
    taskkill /F /PID %%a 2>nul
)

echo.
echo Aplicacao encerrada com sucesso!
echo.
pause
