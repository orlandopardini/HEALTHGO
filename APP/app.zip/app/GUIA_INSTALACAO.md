# 🏥 Plataforma Inteligente de Saúde - MVP

## 🚀 Guia de Instalação e Uso

### Passo 1: Pré-requisitos

Antes de começar, certifique-se de ter instalado:

1. **Python 3.10 ou superior** (mas inferior a 3.14)
   - Download: https://www.python.org/downloads/
   - Durante a instalação, marque "Add Python to PATH"

2. **Node.js 16 ou superior**
   - Download: https://nodejs.org/
   - Inclui o NPM automaticamente

3. **Git** (opcional, mas recomendado)
   - Download: https://git-scm.com/

### Passo 2: Verificar Instalações

Abra o PowerShell ou CMD e execute:

```bash
python --version
# Deve mostrar: Python 3.10.x ou superior

node --version
# Deve mostrar: v16.x.x ou superior

npm --version
# Deve mostrar: 8.x.x ou superior
```

### Passo 3: Configuração Inicial

1. **Navegue até a pasta do projeto:**
   ```bash
   cd "C:\Users\orlando.gardezani\Downloads\CREWAI\CÓDIGO\app"
   ```

2. **Configure as variáveis de ambiente:**
   - Abra o arquivo `.env.example` e copie para `.env`
   - Edite o arquivo `.env` e adicione suas chaves de API:

   ```
   OPENAI_API_KEY=sua-chave-openai-aqui
   SUPABASE_URL=https://itrouyfcsftruntbibvv.supabase.co
   SUPABASE_KEY=sua-chave-supabase-aqui
   ```

   **Como obter as chaves:**
   - OpenAI: Acesse https://platform.openai.com/api-keys
   - Supabase: Acesse seu projeto em https://app.supabase.com

### Passo 4: Instalação Automática

Execute o instalador:

```bash
install.bat
```

O instalador irá:
- ✅ Verificar Python e Node.js
- ✅ Instalar dependências do backend (Python)
- ✅ Instalar dependências do frontend (Node.js)
- ✅ Criar arquivo .env se não existir
- ✅ Configurar banco de dados Supabase

**Tempo estimado:** 5-10 minutos

### Passo 5: Iniciar a Aplicação

Execute o arquivo de inicialização:

```bash
start.bat
```

Isso irá:
- 🚀 Iniciar o backend API na porta 8000
- 🚀 Iniciar o frontend React na porta 3000
- 🌐 Abrir automaticamente no navegador

**URLs de acesso:**
- Frontend: http://localhost:3000
- API Backend: http://localhost:8000
- Documentação API: http://localhost:8000/docs

### Passo 6: Primeiro Uso

1. **Acesse http://localhost:3000**
2. Clique em "Começar Agora"
3. Preencha o formulário de onboarding com seus dados
4. Aguarde a geração do seu plano personalizado
5. Explore as páginas:
   - **Dashboard:** Visão geral do seu progresso
   - **Nutrição:** Plano alimentar detalhado
   - **Treino:** Programa de exercícios
   - **Progresso:** Métricas e evolução
   - **Financeiro:** Análise de custos

---

## 🛠️ Solução de Problemas

### Erro: "Python não encontrado"

**Solução:**
1. Reinstale Python de https://www.python.org/downloads/
2. Durante a instalação, marque "Add Python to PATH"
3. Reinicie o terminal e tente novamente

### Erro: "Node.js não encontrado"

**Solução:**
1. Instale Node.js de https://nodejs.org/
2. Reinicie o terminal
3. Execute `node --version` para verificar

### Erro: "Falha ao conectar com Supabase"

**Solução:**
1. Verifique se as credenciais no arquivo `.env` estão corretas
2. Acesse https://app.supabase.com e confirme que o projeto está ativo
3. Copie novamente as chaves (URL e ANON Key)

### Erro: "Port 3000 already in use"

**Solução:**
Outra aplicação está usando a porta 3000.

Opção 1 - Parar a aplicação:
```bash
# No PowerShell (como administrador)
netstat -ano | findstr :3000
taskkill /PID [número_do_processo] /F
```

Opção 2 - Usar outra porta:
Edite `frontend/package.json` e altere o script start para:
```json
"start": "set PORT=3001 && react-scripts start"
```

### Erro: "OpenAI API Error"

**Solução:**
1. Verifique se sua chave OpenAI é válida
2. Confirme que tem créditos disponíveis em https://platform.openai.com/account/usage
3. Verifique se a chave está no formato correto: `sk-...`

### Backend não inicia

**Solução:**
```bash
cd backend
pip install -r requirements.txt --upgrade
python -m uvicorn api.main:app --reload --port 8000
```

### Frontend não inicia

**Solução:**
```bash
cd frontend
npm install --force
npm start
```

---

## 📚 Estrutura de Arquivos

```
app/
├── backend/                 # API FastAPI
│   ├── api/
│   │   ├── __init__.py
│   │   └── main.py         # Endpoints da API
│   ├── database/
│   │   ├── __init__.py
│   │   ├── setup_database.py    # Setup do BD
│   │   └── supabase_client.py   # Cliente Supabase
│   └── requirements.txt    # Dependências Python
│
├── frontend/               # Aplicação React
│   ├── public/
│   │   ├── index.html
│   │   └── manifest.json
│   ├── src/
│   │   ├── components/     # Componentes reutilizáveis
│   │   │   ├── Header.js
│   │   │   └── Footer.js
│   │   ├── pages/          # Páginas da aplicação
│   │   │   ├── HomePage.js
│   │   │   ├── OnboardingPage.js
│   │   │   ├── DashboardPage.js
│   │   │   ├── NutritionPage.js
│   │   │   ├── TrainingPage.js
│   │   │   ├── ProgressPage.js
│   │   │   └── FinancialPage.js
│   │   ├── services/       # Integrações API
│   │   │   └── api.js
│   │   ├── styles/         # Estilos CSS
│   │   │   ├── index.css
│   │   │   └── App.css
│   │   ├── App.js          # Componente principal
│   │   └── index.js        # Entry point
│   └── package.json        # Dependências Node
│
├── .env.example            # Exemplo de variáveis
├── install.bat             # Script de instalação
├── start.bat               # Script de inicialização
└── README.md               # Documentação principal
```

---

## 🔌 Endpoints da API

### Saúde da API
- `GET /` - Health check
- `GET /health` - Status da API

### Usuários
- `POST /api/users/onboard` - Cadastrar novo usuário
- `GET /api/users/{user_id}` - Buscar perfil do usuário

### Avaliação de Saúde
- `POST /api/assessment/analyze` - Analisar riscos de saúde

### Nutrição
- `POST /api/nutrition/plan` - Criar plano nutricional

### Treino
- `POST /api/training/program` - Criar programa de treino

### Progresso
- `GET /api/progress/{user_id}` - Obter relatório de progresso

### Financeiro
- `POST /api/financial/estimate` - Estimar custos

### CrewAI
- `POST /api/crew/run-full-analysis` - Executar análise completa

**Documentação interativa:** http://localhost:8000/docs

---

## 🗄️ Banco de Dados (Supabase)

### Configuração Manual do Banco

Se o setup automático falhar, execute manualmente:

1. Acesse https://app.supabase.com
2. Abra seu projeto
3. Vá em "SQL Editor"
4. Copie e cole o conteúdo do arquivo `backend/database_schema.sql`
5. Click em "Run"

### Tabelas Criadas

- `users` - Usuários cadastrados
- `user_profiles` - Perfis de saúde
- `health_assessments` - Avaliações de risco
- `nutrition_plans` - Planos nutricionais
- `training_programs` - Programas de treino
- `progress_entries` - Registros de progresso
- `financial_plans` - Planejamento financeiro
- `workout_logs` - Logs de treino
- `meal_logs` - Logs de refeições

---

## 🎨 Personalizações

### Alterar cores do tema

Edite `frontend/src/styles/App.css`:

```css
/* Cor primária */
.btn-primary {
  background-color: #seu-codigo-aqui;
}

/* Gradiente do header */
.header {
  background: linear-gradient(135deg, #cor1 0%, #cor2 100%);
}
```

### Alterar modelo de IA

Edite `.env`:

```env
DEFAULT_LLM_MODEL=openai/gpt-4.1-mini
LLM_TEMPERATURE=0.7
```

Opções disponíveis:
- `openai/gpt-4o`
- `openai/gpt-4.1-mini`
- `anthropic/claude-sonnet-4-20250514`
- `google/gemini-2.0-flash`

---

## 🔒 Segurança

### Dados Sensíveis

- ❌ **NUNCA** compartilhe seu arquivo `.env`
- ❌ **NUNCA** faça commit das chaves de API no Git
- ✅ Mantenha o `.env` no `.gitignore`
- ✅ Use variáveis de ambiente separadas para produção

### Boas Práticas

1. Troque as chaves de API regularmente
2. Use chaves diferentes para desenvolvimento e produção
3. Limite permissões das chaves API ao mínimo necessário
4. Monitore uso de APIs para detectar anomalias

---

## 📞 Suporte

### Problemas Comuns

1. **App não abre:** Verifique se as portas 3000 e 8000 estão livres
2. **Erro de API:** Confirme suas chaves no arquivo `.env`
3. **Lentidão:** Primeira execução pode ser lenta (modelos de IA sendo carregados)

### Logs

Os logs são salvos automaticamente em:
- Backend: Terminal onde executou `start.bat`
- Frontend: Console do navegador (F12)

### Recursos Adicionais

- Documentação CrewAI: https://docs.crewai.com
- Documentação Supabase: https://supabase.com/docs
- FastAPI Docs: https://fastapi.tiangolo.com
- React Docs: https://react.dev

---

## 🚀 Próximos Passos

Após ter a aplicação rodando:

1. ✅ Complete o onboarding com seus dados reais
2. ✅ Explore cada página da aplicação
3. ✅ Teste diferentes perfis de usuário
4. ✅ Customize cores e textos conforme sua preferência
5. ✅ Integre com o CrewAI completo para análises reais
6. ✅ Adicione autenticação de usuários
7. ✅ Deploy em produção (Vercel + Railway/Render)

---

**Desenvolvido com ❤️ usando CrewAI, React e Supabase**
